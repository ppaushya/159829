package org.cap.game.util;

public class Utility {

	public boolean validateCustomerName(String name) {
		
		return(name.matches("[a-zA-z]{3,}"));
		// TODO Auto-generated method stub
		
	}
	
	public boolean validateMobileNumber(String mobile) {
		// TODO Auto-generated method stub
		return(mobile.matches("[7-9]{1}[0-9]{9}"));

		
	}
	
	

}
