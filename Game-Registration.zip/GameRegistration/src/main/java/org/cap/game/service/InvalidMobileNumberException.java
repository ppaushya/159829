package org.cap.game.service;

public class InvalidMobileNumberException extends Exception {
	
	public InvalidMobileNumberException(String string)
	{
		super(string);
	}

}
