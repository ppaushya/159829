package org.cap.game.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.cap.game.boot.BootClass;
import org.cap.game.model.Registration;

public class GameDaoImp implements IGameDao{
	final Logger logger=Logger.getLogger(GameDaoImp.class);
	
	@Override
	public Registration addCustomer(Registration registration) {
String sql="insert into registration values(?,?,?,?,?,?)";
		
		try(Connection connection=getDbConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setInt(1, registration.getRegistrationID());
			statement.setString(2, registration.getCustomerName());
			statement.setString(3, registration.getMobileNo());
			statement.setInt(4, registration.getAge());
			statement.setDouble(5, registration.getRegistrationFee());
			
			statement.setDouble(6, registration.getActualRegistrationFee());
			
			int flag=statement.executeUpdate();
		
			
			if(flag>0)
			{
							
				System.out.println("Registration successful.");
				logger.info("Registration successful. "+registration.toString());
				String sql1="select * from registration";
				statement=connection.prepareStatement(sql1);
				ResultSet resultSet= statement.executeQuery();
				Registration  registration1=new Registration();
				while(resultSet.next()) {
				registration1.setRegistrationID(resultSet.getInt(1));
				registration1.setCustomerName(resultSet.getString(2));
				registration1.setMobileNo(resultSet.getString(3));
				//registration1.setRegistrationFee(resultSet.getDouble(4));
				registration1.setAge(resultSet.getInt(4));
				registration1.setActualRegistrationFee(resultSet.getDouble(6));
				}
				return registration1;

				
			}
			else
			{
				logger.error("Insertion failed");
				
			}

		}
		catch( SQLException e)
		{
			logger.error("Oops! Something went wrong",e);
			e.getMessage();
			//e.printStackTrace();
		}
		
		return null;
		
	}

	
	
	
	
	private Connection getDbConnection()
	{ 
		Connection connection =null;
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			connection =DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		
		return null;
	}
	}


}
