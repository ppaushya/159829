package org.cap.tables;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateRegistrationTable {

	public static void main(String[] args) {
		
		try (Connection connection =DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123")){
			Class.forName("com.mysql.jdbc.Driver");
			
			
			String sql="create table registration(registrationID int primary key auto_increment , \r\n" + 
					"customerName varchar(25), \r\n" + 
					"mobileNo varchar(10),\r\n" + 
					"age int, \r\n" + 
					"registrationFee numeric(8,2), \r\n" + 
					"actualRegistrationFee numeric(8,2))"; 
			Statement statement=connection.createStatement();
			boolean flag=statement.execute(sql);
			if(flag==true)
			{
				System.out.println("Error in table creation");
			}
			else
			{
				System.out.println("Table created successfully");
			}
		
		}
		catch(ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}
		
		// TODO Auto-generated method stub

	}

}
