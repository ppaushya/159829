package org.cap.game.test;

import static org.junit.Assert.*;

//import org.cap.account.service.AccountServiceImpl;
import org.cap.game.dao.IGameDao;
import org.cap.game.model.Registration;
import org.cap.game.service.GameServiceImp;
import org.cap.game.service.IGameService;
import org.cap.game.service.InvalidAgeException;
import org.cap.game.service.InvalidMobileNumberException;
import org.cap.game.service.InvalidNameException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;



import org.mockito.Mock;
import org.mockito.Mockito;

public class GameTest {
	
	@Mock
	private IGameDao gameDao;
	private IGameService gameService;
	

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		gameService =new GameServiceImp(gameDao);
	}
	
	//Testing for invalid Age
	@Test(expected=InvalidAgeException.class)
	public void when_Calcluate_actualFees_age() throws InvalidAgeException
	{
		gameService.calculateActualRegistration(-10);
		
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void is_reg_null() throws InvalidNameException, InvalidMobileNumberException
	{
		Registration registration=null;
		gameService.addCustomer(registration);
	}
	
	//Testing for invalid name
	@Test(expected=InvalidNameException.class)
	public void when_is_Valid_Customer_Invalid_Name() throws InvalidNameException, InvalidMobileNumberException
	{
		Registration registration=new Registration();
		registration.setCustomerName("Anna90");
		registration.setAge(10);
		registration.setActualRegistrationFee(registration.getRegistrationFee());
		registration.setMobileNo("7890654321");
		gameService.addCustomer(registration);
		
	}
	
	
	//Testing for invalid Number
	@Test(expected=InvalidMobileNumberException.class)
	public void when_is_Valid_Customer_Invalid_Mobile() throws InvalidNameException, InvalidMobileNumberException
	{
		Registration registration=new Registration();
		registration.setCustomerName("Annapoorna");
		registration.setAge(10);
		registration.setActualRegistrationFee(registration.getRegistrationFee());
		registration.setMobileNo("0123456");
		gameService.addCustomer(registration);
		
	}
	
	
	
	//Mockito test for inserting customer details
	@Test
	public void when_add_Customer() throws InvalidNameException, InvalidMobileNumberException
	
	
	{
		
		Registration registration=new Registration();
		registration.setRegistrationID(3);
		registration.setCustomerName("Annapoorna");
		registration.setAge(10);
		registration.setActualRegistrationFee(registration.getRegistrationFee());
		registration.setMobileNo("7894561230");
		//dummy
		Mockito.when(gameDao.addCustomer(registration)).thenReturn(registration);
		
		//actual
		gameService.addCustomer(registration);
		//verification
		Mockito.verify(gameDao).addCustomer(registration);
		
		
		
	}
}
