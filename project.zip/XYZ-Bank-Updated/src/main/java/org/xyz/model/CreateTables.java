package org.xyz.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CreateTables {
	
	
	public void createAccountTable()
	{

		String sql="create table Account(accountNo numeric ,accountType varchar(15),openingDate date,openingBalance int, description varchar(40),currentBalance numeric(8,2), customerID int  references Customer(customerID))";
	
		
		try(Connection connection=getDbConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			boolean flag=statement.execute();
		
			
			if(flag==false)
			{
				System.out.println("Table Creation Done!");
			}
			else
			{
				System.out.println("Table Creation failed");
			}
			
			
		}
		catch( SQLException e)
		{
			e.printStackTrace();
		}
	
	}
	
	public void createAddressTable()
	
	{
			String sql="create table Address(addressId int primary key auto_increment,\r\n" + 
					"addressLine1 varchar(25),\r\n" + 
					"addressLine2 varchar(25),\r\n" + 
					"city varchar(25),\r\n" + 
					"state varchar(25),\r\n" + 
					"pincode varchar(25), \r\n" + 
					"customerId int references customer(customerId))";
	
		
		try(Connection connection=getDbConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			boolean flag=statement.execute();
		
			
			if(flag==false)
			{
				System.out.println("Table Creation Done!");
			}
			else
			{
				System.out.println("Table Creation failed");
			}
			
			
		}
		catch( SQLException e)
		{
			e.printStackTrace();
		}
		
	}
	
public void createTransactionTable()
	
	{
			String sql="create table transaction(transactionId int primary key auto_increment,\r\n" + 
					"transactionDate date, \r\n" + 
					"fromAccount numeric references account(accountNumber),\r\n" + 
					"toAccount numeric references account(accountNumber),\r\n" + 
					"amount numeric(8,2),\r\n" + 
					"transactionType varchar(25)\r\n" + 
					"customerID int references customer(customerID)";
	
		
		try(Connection connection=getDbConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			boolean flag=statement.execute();
		
			
			if(flag==false)
			{
				System.out.println("Table Creation Done!");
			}
			else
			{
				System.out.println("Table Creation failed");
			}
			
			
		}
		catch( SQLException e)
		{
			e.printStackTrace();
		}
		
	}
	
	private Connection getDbConnection()
	{ 
		Connection connection =null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection =DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CreateTables createAccountTable=new CreateTables();
		createAccountTable.createAccountTable();

	}

}
