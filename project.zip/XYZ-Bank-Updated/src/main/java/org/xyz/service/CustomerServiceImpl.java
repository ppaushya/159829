package org.xyz.service;



import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.xyz.dao.CustomerDBImpl;
import org.xyz.dao.CustomerDaoImp;
import org.xyz.dao.ICustomerDao;
import org.xyz.model.Account;
import org.xyz.model.Customer;
import org.xyz.model.Transaction;

public class CustomerServiceImpl implements ICustomerService{
	
	private ICustomerDao customerDao=new CustomerDaoImp();
	private ICustomerDao customerDB=new CustomerDBImpl();
	
	

	@Override
	public void createCustomer(Customer customer) {
		if(isValidCustomer(customer)) {
					customerDB.createCustomer(customer);
		}
		
		
	}
	
	private boolean isValidCustomer(Customer customer) {
		boolean flag=false;
		
		if(customer.getDateOfBirth().isBefore(LocalDate.now())) {
			if(customer.getMobile().matches("(7|8|9)\\d{9}"))
				flag=true;
			else
				flag=false;
		}else
			flag=false;
		
		
		return flag;
	}

	@Override
	public List<Customer> getAllCustomers() {
		
		return customerDB.getAllCustomers();
	}

	@Override
	public void addAccountDetails(Customer customer, Account account) {
		// TODO Auto-generated method stub
		customerDao.addAccountDetails(customer, account);
		
	}

	@Override
	public void addTransactionDetails(Customer customer1, Transaction transaction) {
		// TODO Auto-generated method stub
		customerDao.addTransactionDetails(transaction, customer1);
		
	}

	@Override
	public Map<Customer, List<Transaction>> getTransactionDetails() {
		return customerDao.getTransactionDetails();
	}


}
