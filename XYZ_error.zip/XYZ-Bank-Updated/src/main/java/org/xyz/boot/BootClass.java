package org.xyz.boot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import org.xyz.model.Account;
import org.xyz.model.Customer;
import org.xyz.model.Transaction;
import org.xyz.service.CustomerServiceImpl;
import org.xyz.service.ICustomerService;
import org.xyz.view.UserInteraction;

public class BootClass {
	static Scanner scan=new Scanner(System.in);
	
	
	public static void main(String[] args)
	{	
		ICustomerService customerService=new CustomerServiceImpl();	
		
		UserInteraction userInteraction=new UserInteraction();
		List<Customer> customers = null;
		
		customers= customerService.getAllCustomers();
		
		List<Transaction> transactionList;
		
		
		String option = null;
		do {
		System.out.println("1.Create new customer \t2. List all customers\nEnter your choice");
		int choice=scan.nextInt();
		switch(choice)
		{
		case 1:

			int count=customerService.getAllCustomers().size();
			
			Customer customer=userInteraction.getCustomerDetails();
			System.out.println(customer);
			customerService.createCustomer(customer);
			
			
			if(count==customerService.getAllCustomers().size())
				userInteraction.printError("Customer Creation Error! Please Try Again!");
			
			break;
			
		case 2:
					
			userInteraction.printCustomers(customers);
			int a;
			Customer customer1=null;
			customer1=userInteraction.validateCustomerID(customers);
			String option1=null;
			 
			do{
				System.out.println("1.Create an account\t2.Debit/Credit\t3.Fund Transfer\t4.Transaction Summary\t5.View Current Balance");
				a=scan.nextInt();
				switch(a)
				
					{
					case 1:
						Account account=new Account();
						account=userInteraction.addAccount(customer1);
						customerService.addAccountDetails(customer1,account);
						break;
						
					case 2:
						
						account=userInteraction.checkAccountNumber(customer1);
						if(account==null)
							System.out.println("You do not have any accounts");
						else{
						//fromcurrentBalance=account.getOpeningBalance();
							
							double currentBalance= userInteraction.calculateCurrentBalance(account);
						Transaction transaction=userInteraction.debitOrCredit(account, currentBalance);
						
						customerService.addTransactionDetails(account,transaction);
						
						}
						break;
						
					case 3:
						Account fromAccount;
						Account toAccount;
						Customer toCustomer;
						customers= customerService.getAllCustomers();
						long toAccountNo;
						fromAccount=userInteraction.checkAccountNumber(customer1);
						Transaction transaction;
						 double currentBalance;
						 double amount;
						if(fromAccount==null)
							System.out.println("You do not have any accounts");
						else{
						//fromcurrentBalance=fromAccount.getOpeningBalance();
						System.out.println("Enter the To account number ");
						toAccountNo=scan.nextLong();
						toCustomer=userInteraction.getToAccountCustomer(customers,toAccountNo);
						//System.out.println(toCustomer);
						toAccount=userInteraction.checkToAccountNumber(toCustomer,toAccountNo);
						 if(customer1.equals(toCustomer))
						 {
							 System.out.println("From and to accounts cannot be of same customer");
						 }
						 else
						 {
							 do
							 {
						System.out.println("Enter the amount to transfer");
						amount=scan.nextInt();
						
						currentBalance= userInteraction.calculateCurrentBalance(fromAccount);
						 transaction=userInteraction.fromFundTransfer(fromAccount,toAccount, currentBalance,amount);
							 }while(transaction==null);
						
						
						customerService.addTransactionDetails(fromAccount,transaction);
						
						 
						}
						}
						
						
						
						break;
						
					case 4:
						System.out.println("Enter the account No.");
						long accNo=scan.nextInt();
						Account account1=userInteraction.checkToAccountNumber(customer1,accNo);
						//System.out.println(account1);
						transactionList=customerService.getTransactionDetails(account1);
						System.out.println(transactionList);
						transactionList=customerService.getTransactionDetails(account1);
						System.out.println(transactionList);
						break;
						
					case 5:
						
						 System.out.println("Enter the account Number");
						 long accountNo=scan.nextLong();
						 account1=userInteraction.checkToAccountNumber(customer1,accountNo);
						 userInteraction.transactions(account1);
						 currentBalance= userInteraction.calculateCurrentBalance(account1);
						 System.out.println(currentBalance);
						
					}

				System.out.println("Do you wish to contine?[y|n]:");
				option1=scan.next();	
			}while(option1.charAt(0)=='Y'|| option1.charAt(0)=='y');
			
			break;
		}
		
		System.out.println("Do you wish to contine?[y|n]:");
		option=scan.next();
		}while(option.charAt(0)=='Y'|| option.charAt(0)=='y');
	}
}
