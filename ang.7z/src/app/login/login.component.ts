import { Component, OnInit } from "@angular/core";
import { Login } from "./login";
import {  LoginServiceComponent } from "./login.service";
import { Router } from "@angular/router";


@Component({
    templateUrl:'./login.component.html',
    styleUrls:['./login.component.css']
    
})
export class  LoginComponent implements OnInit
{
    login:Login = new Login("","");
    
   
    validLogin:boolean=true;
    constructor(private _loginService:LoginServiceComponent, private _router:Router)
    {
       
    }

    ngOnInit()
    {
        // 0this._loginService.isValidLogin(new Login("mad@gmail.com","123")).subscribe(
        //     login => this.validLogin=login
        // )
    }

    isValidLogin():void{

        this._loginService.isValidLogin(this.login).subscribe(
            login =>{
                this.validLogin=login;
                if(login){
                    
                    this._router.navigate(['/mainPage']);
                }
                else
                {
                    this.login.userName="";
                    this.login.userPassword="";
                    this._router.navigate(['/login']);
                }
            } 
        )
        //console.log(this.validLogin)
        
        }
// this.loginService.doLogin(this.customer)
// .subscribe(customer =>{
// console.log(customer);
// if(customer.emailId==this.customer.emailId){
// console.log("login successful");
// this.loginService.setCustomer(customer);
// this.router.navigate(['/mainpage']);
// }
// });  
 

    

    navigate():void{
        this.isValidLogin();
       
    }



} 
