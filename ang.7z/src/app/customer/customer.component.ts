import { Component, OnInit } from '@angular/core';
import {CustService} from '../cust.service';
import {Customer} from '../customer';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  customers: Customer[];
  customer:Customer=new Customer();

  _listFilter: string;

filteredCustomers: Customer[];

constructor(private custService: CustService) { 

this.listFilter = '';

}

get listFilter(): string {

return this._listFilter;

}

set listFilter(value: string) {

this._listFilter=value;

this.filteredCustomers = this.listFilter ? this.performFilter(this.listFilter)
: this.customers;

}




ngOnInit() {

this.getCustomers();

}

registerCustomer():void{

  this.custService.registerCustomer(this.customer).subscribe(customers => this.customers = customers);

}


getCustomers(): void{

this.custService.getCustomers()

.subscribe(customers => { this.customers= customers;

this.filteredCustomers=this.customers;});

}


performFilter(filterBy: string): Customer[] {

filterBy= filterBy.toLocaleLowerCase();

return this.customers.filter((customer: Customer) =>

customer.firstName.toLocaleLowerCase().indexOf(filterBy) !== -1);

}

// dltcustomer(custId:number){
//   this.custService.deleteCustomer(custId)
// }

deleteCustomer(id:number): void{
  console.log("delete");
  this.custService.deleteCustomer(id)
  .subscribe(customers =>this.filteredCustomers=customers);
  //window.location.reload();
  }

}
