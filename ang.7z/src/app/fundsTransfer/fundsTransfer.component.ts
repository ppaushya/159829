import { Component, OnInit } from "@angular/core";
import { Customer } from "../mainPage/Customer";
import { Account } from "../createAccount/account";
import { Transaction } from "../despositWithdraw/transaction";
import { depositWithdrawServiceComponent } from "../despositWithdraw/depositWithdraw.service";
import { Router } from "@angular/router";
//import { depositWithdrawServiceComponent } from "../despositWithdraw/depositWithdraw.service";


@Component({
    templateUrl:'./fundsTransfer.component.html',
    styleUrls:['./fundsTransfer.component.css']
    
})
export class  FundsTransferComponent implements OnInit
{

    fromAccounts:Account[];
    toAccounts:Account[];
   transaction: Transaction =

    {
        "transactionID":0,
        "amount":0,
        "description":"",
        "transactionDate":new Date(),
        "transactionType":"Funds",
        "customer": new Customer(),
        "fromAccount": new Account(),
        "toAccount": new Account()
    };

    message:string="";
    constructor(private _depostiWithdrawService: depositWithdrawServiceComponent, private _router: Router) {

    }

    ngOnInit(){
        this._depostiWithdrawService.getAccounts().subscribe(accounts=>{
            this.fromAccounts=accounts;
        })
        this._depostiWithdrawService.getOtherAccounts().subscribe(accounts=>this.toAccounts=accounts)
    }


    fundsTransfer(): void {
        // this.transaction.customer=null;
        // this.transaction.toAccount=null;
        // this.transaction.transactionDate=null;
        console.log(this.transaction);
        
       for(let account of this.fromAccounts)
       {
           if(account.accountNumber==this.transaction.fromAccount.accountNumber)
                this.transaction.fromAccount=account;
       }
       for(let account of this.toAccounts)
       {
           if(account.accountNumber==this.transaction.toAccount.accountNumber)
                this.transaction.toAccount=account;
       }

        this._depostiWithdrawService.depositWithdraw(this.transaction).subscribe(flag=>{
            
            if(flag){
                this._router.navigate(['/mainPage'])
            }
            else
            {
                this.message="Please enter Amount less than current balance";
                this._router.navigate(['/fundsTransfer']) 
            }
        });

    }


    
} 
