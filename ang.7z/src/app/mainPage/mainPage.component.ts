import { Component } from "@angular/core";


@Component({
    templateUrl:'./mainPage.component.html',
    
    
})
export class  MainPageComponent
{

} 