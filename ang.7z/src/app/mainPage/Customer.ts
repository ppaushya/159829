import { Account } from "../createAccount/account";
import { Address } from "./Address";


export class Customer
{
    customerId:number;
    firstName:string;
	lastName:string;
	dateOfBirth:Date;
	emailId:string;
	mobile:string;
	customerPwd:string;
	address:Address;
	accounts:Set<Account>;
	
}