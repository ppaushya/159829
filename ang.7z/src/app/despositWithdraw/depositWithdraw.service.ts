import { Injectable } from "@angular/core";
import { HttpClient,  HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Transaction } from "./transaction";
import { Account } from "../createAccount/account";



const header=new HttpHeaders({ 'Content-Type': 'application/json'})

@Injectable()
export class depositWithdrawServiceComponent
{
    private _loginUrl="http://localhost:8080/ParallelProjectSpring/project/depositWithdraw";


    constructor(private _http: HttpClient){}

    depositWithdraw(transaction: Transaction):Observable<boolean>
    {
       return this._http.post<boolean>(this._loginUrl,transaction,{headers:header});
    }

    getAccounts():Observable<Account[]>{
        let _loginUrl2=this._loginUrl+"/getAccounts"
        return this._http.get<Account[]>(_loginUrl2);
    }
    
    getOtherAccounts():Observable<Account[]>{
        let _loginUrl2=this._loginUrl+"/getOtherAccounts"
        return this._http.get<Account[]>(_loginUrl2);
    }
    

}