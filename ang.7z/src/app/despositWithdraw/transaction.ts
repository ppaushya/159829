import { Customer } from "../mainPage/Customer";
import { Account } from "../createAccount/account";

export class Transaction{
    "transactionID":number;
    "amount":number;
    "description":string;
    "transactionDate":Date;
    "transactionType":string;
    "customer": Customer;
    "fromAccount": Account;
    "toAccount": Account;
}