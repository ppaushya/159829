import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { depositWithdrawServiceComponent } from "./depositWithdraw.service";
import { Transaction } from "./transaction";
import { Account } from "../createAccount/account";
import { Customer } from "../mainPage/Customer";



@Component({
    templateUrl:'./depositWithdraw.component.html',
    styleUrls:['./depositWithdraw.component.css']
    
})
export class  DepositWithdrawComponent implements OnInit
{
    transaction: Transaction=

    {
        "transactionID":0,
    "amount":0,
    "description":"",
    "transactionDate":new Date(),
    "transactionType":"",
    "customer": new Customer(),
    "fromAccount": new Account(),
    "toAccount": new Account()
    }
    
    message:string="";
    
    accounts : Account[];
     
    constructor(private _depostiWithdrawService: depositWithdrawServiceComponent, private _router: Router) {

    }

    ngOnInit(){
        this._depostiWithdrawService.getAccounts().subscribe(accounts=>{
            this.accounts=accounts;
        })
    }

    depostiWithdraw(): void {
        // this.transaction.customer=null;
        // this.transaction.toAccount=null;
        // this.transaction.transactionDate=null;
        console.log(this.transaction);
        
       for(let account of this.accounts)
       {
           if(account.accountNumber==this.transaction.fromAccount.accountNumber)
                this.transaction.fromAccount=account;
       }
        this._depostiWithdrawService.depositWithdraw(this.transaction).subscribe(flag=>{
            
            if(flag){
                this._router.navigate(['/mainPage'])
            }
            else
            {
                this.message="Please enter Amount less than current balance";
                this._router.navigate(['/depositWithdraw']) 
            }
        });

    }

} 
