import { Component } from "@angular/core";

import { Router } from "@angular/router";
import { createAccountServiceComponent } from "./createAccount.service";
import { Customer } from "../mainPage/Customer";
import { Account } from "./account";


@Component({
    templateUrl: './createAccount.component.html',
    styleUrls: ['./createAccount.component.css']

})
export class CreateAccountComponent {
    account: Account = new Account();

    constructor(private _accountService: createAccountServiceComponent, private _router: Router) {

    }

    createAccount(): void {

        this._accountService.createAccount(this.account).subscribe(flag => {
            if(flag){
                this._router.navigate(['/mainPage'])
            }
            else
            {
                this._router.navigate(['/createAccount']) 
            }
        });
        

    }

} 
