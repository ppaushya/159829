import { Customer } from "../mainPage/Customer";

export class Account{

   accountNumber:number;
	accountType:string;
	openingDate:Date;
	openingBalance:number;
	description:string;
    customer:Customer;
	
}
