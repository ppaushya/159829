import { Injectable } from "@angular/core";
import { HttpClient,  HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Account } from "./account";



const header=new HttpHeaders({ 'Content-Type': 'application/json'})

@Injectable()
export class createAccountServiceComponent
{
    private _loginUrl="http://localhost:8080/ParallelProjectSpring/project/createAccount";


    constructor(private _http: HttpClient){}

    createAccount(account: Account):Observable<boolean>
    {
       return this._http.post<boolean>(this._loginUrl,account,{headers:header});
    }

}