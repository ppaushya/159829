package org.uas.model;

public class Participant {
	private int rollNo;
	private String emailId;
	private Application application;
	private int scheduledProgramId;
	
	
	public Participant() {
		super();
	}


	public Participant(int rollNo, String emailId, Application application, int scheduledProgramId) {
		super();
		this.rollNo = rollNo;
		this.emailId = emailId;
		this.application = application;
		this.scheduledProgramId = scheduledProgramId;
	}


	public int getRollNo() {
		return rollNo;
	}


	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}


	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	public Application getApplication() {
		return application;
	}


	public void setApplication(Application application) {
		this.application = application;
	}


	public int getScheduledProgramId() {
		return scheduledProgramId;
	}


	public void setScheduledProgramId(int scheduledProgramId) {
		this.scheduledProgramId = scheduledProgramId;
	}


	@Override
	public String toString() {
		return "Participant [rollNo=" + rollNo + ", emailId=" + emailId + ", application=" + application
				+ ", scheduledProgramId=" + scheduledProgramId + "]";
	}
	
	
	
	
	
	
	
	
}
