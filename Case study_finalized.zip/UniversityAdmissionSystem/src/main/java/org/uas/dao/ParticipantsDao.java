package org.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.uas.model.Participant;

public class ParticipantsDao {
	UAS_Dao_Impl uasDao=new UAS_Dao_Impl();
	
	//Create new Participant in the participant table
public boolean createParticipant(Participant participant) {
		
		String sql="insert into participant(roll_no, email_id, Application_id,scheduled_program_id) values(?,?,?,?)";
		try(Connection connection=uasDao.getConnection())
		{
			PreparedStatement pst=connection.prepareStatement(sql);
			
			pst.setInt(1, participant.getRollNo());
			pst.setString(2, participant.getEmailId());
			pst.setInt(3, participant.getApplication().getApplicationId());
			pst.setInt(4, participant.getScheduledProgramId());
			
			int flag=pst.executeUpdate();
			if(flag>0)
			{
				uasDao.logger.info("Participant Record inserted successfully");
				return true;
			}
		}catch(SQLException e)
		{
			uasDao.logger.error("Error occured"+e);
		}
		return false;
	}

}
