package org.uas.view;

import java.util.List;

import org.uas.model.ProgramsOffered;
import org.uas.model.ProgramsSchedule;

public class Utility {

	//print all Programs offered by the university
	public static void printAllPrograms(List<ProgramsOffered> programs, List<ProgramsSchedule> programs_schedule) {
		

		
		System.out.println("ProgramId \tProgram Title\t Duration(years) \tEligibility \t\t Degree Certificate\t StartDate \t End Date\t Location");
		System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------");
		
	for(ProgramsSchedule program_schedule:programs_schedule)
	{
		for(ProgramsOffered program:programs)
		{
			
			
			if(program_schedule.getProgramName().compareTo(program.getProgramName())==0)
			{System.out.print(program_schedule.getScheduleProgramId()+".\t\t");
			
			System.out.print(program.getProgramName()+"\t\t\t");
			System.out.print(program.getDuration()+"\t");
			System.out.print(program.getApplicantEligibility()+"\t");
			System.out.print(program.getDegreeCertificateOffered()+"\t\t");			
			System.out.print(program_schedule.getStartDate()+"\t");
			System.out.print(program_schedule.getEndDate()+"\t");
			System.out.print(program_schedule.getLocation());
			System.out.println();
			}
			
		
		}
	}
	
	System.out.println();
	
	
	/*for(ProgramsSchedule program_schedule:programs_schedule)
	{
		for(ProgramsOffered program:programs)
		{
			

			if(program_schedule.getProgramName().compareTo(program.getProgramName())==0)
				System.out.println(program_schedule.getScheduleProgramId()+"."+ program.getProgramName());
			
			
		}
		
	
	}	*/
			
	}

	//TO genereate the random value of 3 digit
	public static int generatevalue() {
	
		return (int)(Math.random()*1000);
	}

	//Heading design generation
	public static void generateDesign() throws InterruptedException {
		
		
		System.out.println();
		System.out.println("-------------------------------------------------------------------------------------------");
		
		System.out.print("\t\t\t\t");
			Thread.sleep(100);
		System.out.print("*");
		Thread.sleep(100);
		System.out.print("*");
		Thread.sleep(100);
		System.out.print("*");
		Thread.sleep(100);
		System.out.print("*");
		Thread.sleep(100);
		System.out.print("*");
		Thread.sleep(100);
		System.out.print("*");
		Thread.sleep(100);
		System.out.print(" ");
		Thread.sleep(100);
		System.out.print("B");
		Thread.sleep(100);
		System.out.print("R");
		Thread.sleep(100);
		System.out.print("O");
		Thread.sleep(100);
		System.out.print(" ");
		Thread.sleep(100);
		System.out.print("U");
		Thread.sleep(100);
		System.out.print("N");
		Thread.sleep(100);
		System.out.print("I");
		Thread.sleep(100);
		System.out.print("V");
		Thread.sleep(100);
		System.out.print("E");
		Thread.sleep(100);
		System.out.print("R");
		Thread.sleep(100);
		System.out.print("S");
		Thread.sleep(100);
		System.out.print("I");
		Thread.sleep(100);
		System.out.print("T");
		Thread.sleep(100);
		System.out.print("Y");
		Thread.sleep(100);
		System.out.print(" ");
		Thread.sleep(100);
		System.out.print("*");
		Thread.sleep(100);
		System.out.print("*");
		Thread.sleep(100);
		System.out.print("*");
		Thread.sleep(100);
		System.out.print("*");
		Thread.sleep(100);
		System.out.print("*");
		Thread.sleep(100);
		System.out.print("*");
		Thread.sleep(100);
		System.out.println();
		System.out.println("-------------------------------------------------------------------------------------------");
		
		Thread.sleep(600);
		
		System.out.println();
		
		
	}

}
