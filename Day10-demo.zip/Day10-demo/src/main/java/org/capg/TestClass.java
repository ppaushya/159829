package org.capg;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import org.capg.Employee;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserInteraction userInteraction=new UserInteraction();
		Scanner scan=new Scanner(System.in);
		EmployeeDao dao=new EmployeeDaoImp();
		Employee employee=new Employee();
		int choice;
		String option;
		do {
		System.out.println("1.Create Employee\t2.Update Employee\t3.Delete Employee\t4.List All Employees\n5.Find Employee\t\t6.Call procedure\t7.Batch Processing\t8.Exit");
		System.out.println("Enter your choice");
		choice=scan.nextInt();
		
		//Employee employee=new Employee(102,"dufhd","dfjklsdfj",10283,LocalDate.now());
		switch(choice)
		{
		case 1:
			 employee=userInteraction.createCustomer();
			dao.createEmployee(employee);
			break;
		case 2:
			
			int empID=userInteraction.promptEmployeeID();
			
			userInteraction.updateEmployee(empID);
			break;
		case 3:
			int empId=userInteraction.promptEmployeeID();
			dao.deleteEmployee(empId);
			break;
		case 4:
			List<Employee> employees= dao.getAllEmployees();
			userInteraction.printAllEmployees(employees);
			break;
		case 5:
			
			empID=userInteraction.promptEmployeeID();
			Employee employee1=dao.findEmployee(empID);
			System.out.println(employee1);
			userInteraction.printEmployee(employee1);
			break;
		case 6:
			int emplyId=userInteraction.promptEmployeeID();
			Employee employee2= dao.callProcedure(emplyId);
			System.out.println(employee2);
			break;
			
		case 7:
			dao.callBulkInsertion();
			break;
		default:
			System.out.println("Sorry! Invalid Option!");
		}
		System.out.println("You wish to continue[y|n]:");
		option=scan.next();
		
		}while(option.charAt(0)=='y'||option.charAt(0)=='Y');
	}
		
		}
		//dao.createEmployee(employee);
	

	


