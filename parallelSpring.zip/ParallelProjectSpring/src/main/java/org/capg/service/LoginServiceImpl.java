package org.capg.service;

import org.capg.dao.ILoginDao;
import org.capg.model.LoginBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("loginService")
public class LoginServiceImpl implements ILoginService{

	@Autowired
	ILoginDao loginDao;
	
	@Override
	public LoginBean isValidLogin(LoginBean login) {
		
		return loginDao.isValidLogin(login);
		// TODO Auto-generated method stub
		
	}

}
