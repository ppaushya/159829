package org.capg.service;

import org.capg.model.LoginBean;

public interface ILoginService {

	public abstract LoginBean isValidLogin(LoginBean login);
	
	

}
