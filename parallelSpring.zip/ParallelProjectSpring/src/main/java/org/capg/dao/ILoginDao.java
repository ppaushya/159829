package org.capg.dao;

import org.capg.model.LoginBean;

public interface ILoginDao {

	LoginBean isValidLogin(LoginBean login);

}
