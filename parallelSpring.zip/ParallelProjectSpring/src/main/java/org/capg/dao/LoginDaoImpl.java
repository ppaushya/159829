package org.capg.dao;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.capg.model.LoginBean;
import org.springframework.stereotype.Repository;

@Repository("loginDao")
@Transactional
public class LoginDaoImpl implements ILoginDao{

	@PersistenceContext
	EntityManager em;
	
	@Override
	public LoginBean isValidLogin(LoginBean login) {
		// TODO Auto-generated method stub
	
			System.out.println(login);
		
			
				Query query=em.createQuery("from LoginBean where userName=:userName and userPassword=:userPassword");
				query.setParameter("userName", login.getUserName());
				query.setParameter("userPassword", login.getUserPassword());
				List<LoginBean> login1=query.getResultList();
			/*String str="from LoginBean where userName="+login.getUserName()+" and userPassword="+login.getUserPassword();
			List<LoginBean> login1=em.createQuery(str).getResultList();*/
			if(login1.isEmpty())
			{
				return new LoginBean();
			}
		return login1.get(0);
		
		
	

}
}
