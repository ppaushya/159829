package org.capg.controller;

import org.capg.model.LoginBean;
import org.capg.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/project")
@CrossOrigin(origins="*")
public class BankController {
	@Autowired
	ILoginService loginService;
	
	
	@GetMapping(value="/login/{userName}/{password}")
	public ResponseEntity<LoginBean> isValidLogin(ModelMap map, @PathVariable("userName") String userName, @PathVariable("password") String password)
	{
		
		LoginBean login=new LoginBean(userName, password);
		
		LoginBean flag=loginService.isValidLogin(login);
		if()
		System.out.println(flag);
		return  new ResponseEntity<LoginBean>(flag, HttpStatus.OK); 
		
	}

}
