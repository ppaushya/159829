package org.xyz.service;

import java.util.List;
import java.util.Map;

import org.xyz.model.Account;
import org.xyz.model.Customer;
import org.xyz.model.Transaction;

public interface ICustomerService {

	public abstract void createCustomer(Customer customer);
	public abstract List<Customer> getAllCustomers();
	//public abstract void createAccount(Account account);
	public abstract void addAccountDetails(Customer customers, Account account);
	public abstract void addTransactionDetails(Customer customer1, Transaction transaction);
	public abstract Map<Customer,List<Transaction>> getTransactionDetails();
	
}
