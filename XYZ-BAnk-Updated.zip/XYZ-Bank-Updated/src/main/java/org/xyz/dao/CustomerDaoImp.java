package org.xyz.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.xyz.model.Account;
import org.xyz.model.Address;
import org.xyz.model.Customer;
import org.xyz.model.Transaction;

public class CustomerDaoImp implements ICustomerDao {
	
	List<Customer> customers=dummyDB();
	List<Transaction> transactionList=new ArrayList<>();
	Map<Customer, List<Transaction>> transactions=dummyDB1();
	
	private static List<Customer> dummyDB(){
		List<Customer> customers=new ArrayList<>();
		
		Address address=new Address("23,west Car St", "2nd St", "Chennai", "TN", 234442);
		customers.add(new Customer(123,"Jack","Thomson", LocalDate.of(1991, 01, 23),
				"8890912345","jack@gmail.com",address));
		
		Address address1=new Address("North Avnnue", "2nd Cross St", "Hyderabad", "AP", 657657);
		customers.add(new Customer(1090,"Tom","Jerry", LocalDate.of(1987, 12, 23),
				"9090912345","tom@gmail.com",address1));
		
		return customers;
	}

	private static Map<Customer, List<Transaction>> dummyDB1() {
		Map<Customer, List<Transaction>> transactions=new HashMap<>();
		return transactions;
	}

	@Override
	public List<Customer> getAllCustomers() {
		
		return customers;
	}

	@Override
	public void createCustomer(Customer customer) {
		
		customers.add(customer);
	}
	
	@Override
	public void addAccountDetails(Customer customer, Account account) {
		
		customer.getAccount().add(account);
		
		
	}
	
	@Override
	public void addTransactionDetails(Transaction transaction,Customer customer)
	
	{
		transactionList.add(transaction);
		transactions.put(customer, transactionList);
		
	}

	@Override
	public Map<Customer, List<Transaction>> getTransactionDetails() {
		// TODO Auto-generated method stub
		return transactions;
	}
	
	
}
