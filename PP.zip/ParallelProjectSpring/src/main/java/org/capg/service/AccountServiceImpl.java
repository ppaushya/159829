package org.capg.service;

import java.util.List;

import org.capg.dao.IAccountDao;
import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("accountService")
public class AccountServiceImpl implements IAccountService{

	@Autowired
	IAccountDao accountDao;

	@Override
	public boolean addAccount(Account account) {
		return accountDao.addAccount(account);
	}

	@Override
	public List<Account> getAccounts(Customer customer) {
		return accountDao.getAccounts(customer);
	}
	

	@Override
	public Boolean addTransaction(Transaction transaction) {
		double currentBalance=findCurrentBalance(transaction.getFromAccount(), accountDao.getTransaction(transaction.getFromAccount()));
		if(currentBalance>=transaction.getAmount() && transaction.getTransactionType().equals("Debit"))
			return accountDao.addTransaction(transaction);
		else 
			return false;
	}
	
	private double findCurrentBalance(Account account,List<Transaction> transactions) {
		double currentBalance=account.getOpeningBalance();
		for(Transaction trans:transactions) {
			if(trans.getFromAccount().getAccountNumber()==account.getAccountNumber() && trans.getTransactionType().equals("Credit"))
			{
				currentBalance+=trans.getAmount();
			}
			else if(trans.getFromAccount().getAccountNumber()==account.getAccountNumber() && trans.getTransactionType().equals("Debit"))
			{
				currentBalance-=trans.getAmount();
			}
			else if(trans.getToAccount().getAccountNumber()==account.getAccountNumber() && trans.getTransactionType().equals("Funds"))
			{
				currentBalance+=trans.getAmount();
			}
			else if(trans.getFromAccount().getAccountNumber()==account.getAccountNumber() && trans.getTransactionType().equals("Funds"))
			{
				currentBalance-=trans.getAmount();
			}
		}
			
		return currentBalance;
		
	}

	@Override
	public List<Account> getOtherAccounts(Customer customer) {
		// TODO Auto-generated method stub
		return accountDao.getOtherAccounts(customer);
	}

	
	
}
