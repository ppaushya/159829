import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Email',
  templateUrl: './Email.component.html',
  styleUrls: ['./Email.component.css']
})
export class EmailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
