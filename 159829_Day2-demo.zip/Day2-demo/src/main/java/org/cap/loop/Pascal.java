package org.cap.loop;

public class Pascal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,k;
		for( i=0;i<5;i++)
		{
			for(j=4;j>i;j--) System.out.print(" ");
			int num=1;
			for(k=0;k<=i;k++)
			{
				System.out.print(num+" ");
				num=num*(i-k)/(1+k);
			}
			System.out.println();
				
		}

	}

}
