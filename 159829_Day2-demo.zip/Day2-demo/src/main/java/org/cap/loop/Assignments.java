package org.cap.loop;

public class Assignments {
	
	public void assignment1(int num)
	{
		int i=0;
		int no=1;
		int no1=2;
		while(no<num)
		{
			for(i=0;i<3;)
		{
			if(no%2!=0)
			{
				System.out.print(no+" ");
				i++;
			}
			
			no++;
			if(no>=num)
				break;
		}
			for(int j=0;j<3;)
			{
			if(no1%2==0)
			{
				System.out.print(no1+" ");
				j++;
			}
			no1++;
			if(no1>=num)
				break;
			}
			
		}
			
			
		}
		
		public void SumofDigits(int num)
		{
			int sum=0;
			
			while(num!=0)
			{
			
			sum=sum+num%10;
			num=num/10;
			}
			System.out.print(sum);
			
		}
		
		public boolean isPrime(int num)
		{
			int cnt=0,a;
			boolean isPrimeNo=false;
			for(a=2;a<num/2;a++)
				
			{
			if(num%a==0 )
			{
				cnt++;
			}
			
			}
			if(cnt==0)
			{
				isPrimeNo=true;
			
			}
			else
			{
				isPrimeNo=false;
			}
			return isPrimeNo;
			
		}
		
		public void PrimeNumber(int num)
		{
			for(int i=2;i<=num;i++)
			{
				boolean prime;
				prime=isPrime(i);
				if(prime==true)
				{
					System.out.println(i);
				}
			}
		}
		
		public boolean isArmstrong(int num)
		{
			int no,sum=0,num1=num;
			boolean arm=false;
			while(num1!=0)
			{
				no=num1%10;
				sum=sum+no*no*no;
				num1=num1/10;
			}
			if(sum==num)
			{
				arm=true;
			}
			return arm;
			
		}
		
		public void Armstrong(int num)
		{
			boolean arm;
			for(int i=1;i<=num;i++)
			{
				arm=isArmstrong(i);
				if(arm==true)
				{
					System.out.println(i);
				}
			}
			
		}
		public void FormatString(String str)
		{
			int a=str.length();
			for(int i=0;i<a+1;i++)
			{
				for(int j=0;j<i;j++)
				{
					System.out.print(str.charAt(j));
				}
				System.out.println();
			}
		} 
	
		

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Assignments obj=new Assignments();
		//boolean isPrime;
		//obj.assignment1(20);
		//obj.SumofDigits(12345);
		//obj.Armstrong(1000);
		obj.FormatString("Hello");
		//System.out.println("Is number Prime?: "+isPrime);
	}

}
