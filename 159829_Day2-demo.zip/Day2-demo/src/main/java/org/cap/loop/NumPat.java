package org.cap.loop;

public class NumPat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c=1;
		for(int i=1;i<5;i++)
		{
			for(int j=0;j<i;j++)
			{
				System.out.print(c+"\t");
				c++;
			}
		System.out.println();
		}

	}

}
