package org.cap.loop;

public class forLoopDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,k;
		for(i=0;i<4;i++)
		{
			for(j=0;j<i;j++)
			{
				
				System.out.print(" \t");
			}
			for(k=0;k<4-i;k++)
			{
				System.out.print("*\t");
			}
			System.out.println();
		}
	}

}
