package org.cap.demo;

import java.util.Scanner;

public class productDetails {
	String prodNAme;
	int prodId;
	int quantity;
	float price;
	float discount;
	float tax;
	public void getProductDetails()
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Product NAme");
		prodNAme=scan.next();
		System.out.println("Enter Product ID");
		prodId=scan.nextInt();
		System.out.println("Enter Quantity");
		quantity=scan.nextInt();
		System.out.println("Enter Price");
		price=scan.nextFloat();
		System.out.println("Enter Discount %");
		discount=scan.nextFloat();
		scan.close();
			
	}
	public float calculateDiscount()
	{
		float disc=price*quantity*discount/100;
		return disc;
	}
	public double calculateTax()
	{
		double taxamt;
		if(discount>=90)
		{
			taxamt=0.01*price*quantity;
		}
		else if(discount>=80 && discount<90)
		{
			taxamt=0.12*price*quantity;
		}
		else if(discount>=60 && discount<80)
		{
			taxamt=0.2*price*quantity;
		}
		else if(discount>=50 && discount<60)
		{
			taxamt=0.25*price*quantity;
		}
		else
		{
			taxamt=0.4*price*quantity;
		}
		return taxamt;
	}
	
	public double findPrice()
	{
		double finalamt;
		float a= calculateDiscount();
		double b= calculateTax();
		finalamt=(price*quantity)+b-a;
		return finalamt;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		productDetails obj=new productDetails();
		
		//String choice;
		do {
			obj.getProductDetails();
			double amt=obj.findPrice();
		System.out.println("Product NAme: "+obj.prodNAme);
		System.out.println("Product ID: "+obj.prodId);
		System.out.println("Quantity: "+obj.quantity);
		System.out.println("Discount: "+obj.discount);
		System.out.println("Final Amount: "+amt);
		System.out.println("Do you wanna continue?");
		
		i++;
		}while(i<2);
	}

}
