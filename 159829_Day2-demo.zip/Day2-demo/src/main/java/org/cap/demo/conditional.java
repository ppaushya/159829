package org.cap.demo;

import java.util.Scanner;

public class conditional {
		public void testIf(int i)
		{
			
			if(i>0)
			{
				System.out.println("Positive Integer");
				if(i%2==0)
				System.out.println("Even number");
				else
					System.out.println("Odd number");
			}
			else if(i==0)
			{
				System.out.println("Is zero");
			}
			else
			{
				System.out.println("Negative Integer");
			}
		}
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int i;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the value");
		i=scan.nextInt();
		scan.close();
		conditional obj= new conditional();
		obj.testIf(i);
	}

}
