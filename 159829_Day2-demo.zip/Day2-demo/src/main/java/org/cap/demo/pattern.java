package org.cap.demo;

public class pattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i=2;
		int num=0;
		int cnt=0;
		while(i<=100)
		{
			for(cnt=0;cnt<5;) {
				
				if(i%2==0)
				{
					
					if(cnt==num )
					{
					System.out.print(i+" ");
					}
					else
					{
						System.out.print("* ");
					}
					cnt++;
				
				}
				i++;

			}
			System.out.println();
			cnt=0;
			num++;
			if(num==5)
			{
				num=0;
			}
		}
		
	}

}
