package org.cap.demo;

public class switchCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			String num="true";
			char ch='a';
		
			/*switch(num)
			{
			case "true":
			{
				System.out.println("1");
				break;
			}
			case "false":
			{
				System.out.println("0");
				break;
			}
			
			default:
			{
				System.out.println("None");
				break;
			}
				
			}*/
			switch(ch)
			{
			case 'A':
			{
				
				System.out.println("65");
				break;
			}
			case 'a':
			{
				System.out.println("98");
				break;
			}
			
			default:
			{
				System.out.println("None");
				break;
			}
				
			}
			int b=Character.getNumericValue(ch);
	}

}
