package org.cap.demo;

public class evenNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=1,sum=0;
		int cnt=0;
		/*while(i<=100)
		{
			if(i%2==0)
			{	
				if(i%10!=0)
				System.out.print(i+", ");
				
				if(i%10==0)
				{
					System.out.print(i);
					System.out.print("\n");
				}
			}
			
		i++;
		}*/
		while(i<=100)
		{
			while(cnt<5)
			{
				
				if(i%2==0)
				{
					System.out.print(i+" ");
					cnt++;
					sum=sum+i;
				}
				i++;
			}
			System.out.println();
			cnt=0;
			
		}
		System.out.println("Sum of all even numbers:"+sum);
		
	}

}
