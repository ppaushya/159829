package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;

/**
 * Servlet implementation class FundsTransferServlet
 */
@WebServlet("/FundsTransferServlet")
public class FundsTransferServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session=request.getSession();
		int custId=(Integer)session.getAttribute("custId");
		//System.out.println(custId);
		ILoginService loginService=new LoginServiceImpl();
		List<Account> accounts= new ArrayList<>();
		
			accounts=loginService.getAccounts(custId);
			
			PrintWriter out=response.getWriter();
			System.out.println(accounts);
			out.println("<!DOCTYPE html>\r\n" + 
					"<html>\r\n" + 
					"<head>\r\n" + 
					"<meta charset=\"ISO-8859-1\">\r\n" + 
					
					"<title>Insert title here</title>\r\n" + 
					"<link type=\"text/css\" rel=\"stylesheet\" href=\"styles/internal.css\">" +
					"<script type=\"text/javascript\" src=\"script/fundsValidate.js\"></script>\r\n" + 
					"</head>\r\n" + 
					"<body>\r\n" + 
					"\r\n" + 
					"<form onsubmit=\"return fundsValidate()\" method=\"post\" action=\"FundsTransferCurrentBalance\">\r\n" + 
					"<table>\r\n" + 
					"<tr>\r\n" + 
					"<td class=\"head\" > From Account: </td></tr><tr> \r\n" + 
					"<td> <select name=\"fromAccount\">\r\n" );

			for(Account account:accounts)
			{
				out.println( "<option value="+account.getAccountNumber()+">"+account.getAccountNumber()+"- "+account.getAccountType()+"</option>");
			}
			
					
			out.println("</select>\r\n" + 
					"</td>\r\n" + 
					"</tr>\r\n" + 
					"<tr>\r\n" + 
					"<td class=\"head\" > To Account: </td></tr><tr>\r\n" + 
					"<td> <select name=\"toAccount\">\r\n");
		
			accounts=loginService.getToAccounts(custId);
			
			for(Account account:accounts)
			{
				out.println( "<option value="+account.getAccountNumber()+">"+account.getAccountNumber()+"- "+account.getAccountType()+"</option>");
			}
			
			out.println("</select>\r\n" + 
					"</td>\r\n" + 
					"</tr>\r\n" + 
					"\r\n" + 
					"<tr>\r\n" + 
					"<td class=\"head\" > Amount</td> </tr><tr>\r\n" + 
					"<td> <input type=\"text\" name=\"amount\" id=\"amount\"></td>\r\n"
					+ "<td><div id=\"errmsg\">"+session.getAttribute("errmsg")+"</div></td>" + 
					"</tr>\r\n" + 
					"\r\n" + 
					"\r\n" + 
					"<tr>\r\n" + 
					"<td class=\"head\" > Description</td></tr><tr>\r\n" + 
					"<td> <input type=\"text\" name=\"description\" id=\"description\"></td></tr><tr>\r\n" + 
					"</tr>\r\n" + 
					"<tr> <td style=\"padding-left:100px\"><input type=\"submit\" name=\"Continue\" value\"Continue\" id=\"btn\"></td></tr>"+
					"</table>\r\n" + 
					"\r\n" + 
					"\r\n" + 
					"</form>\r\n" + 
					"\r\n" + 
					"</body>\r\n" + 
					"</html>");
		
		
	}

	

}
