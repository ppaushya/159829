package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;

/**
 * Servlet implementation class FundsTransferCurrentBalance
 */
@WebServlet("/FundsTransferCurrentBalance")
public class FundsTransferCurrentBalance extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		HttpSession session=request.getSession();
		int customerID=(Integer)session.getAttribute("custId");
		int accNo=Integer.parseInt(request.getParameter("fromAccount"));
		int toAccNo=Integer.parseInt(request.getParameter("toAccount"));
		double amount=Double.parseDouble(request.getParameter("amount"));
		String transactionType="Debit";
		
		ILoginService loginService=new LoginServiceImpl();
		double currentBalance=loginService.getCurrentBalance(customerID, accNo);
		System.out.println(currentBalance);
		if(currentBalance < amount )
		
		{
			
			session.setAttribute("errmsg", "Please enter amount less than current Balance");
			response.sendRedirect("FundsTransferServlet");
		}
		else 
		{
			String description=request.getParameter("description");
			Transaction transaction=new Transaction();
			transaction.setFromAccount(accNo);
			transaction.setToAccount(toAccNo);
			transaction.setDescription(description);
			transaction.setTransactionType(transactionType);
			transaction.setAmount(amount);
			transaction.setTransactionDate(LocalDate.now());
			Customer customer=new Customer();
			customer.setCustomerId(customerID);
			transaction.setCustomer(customer);
			
			Transaction transaction1=loginService.addTransactionDetails(transaction);
			if(transaction1!=null)
			{
				System.out.println("gf");
				
				PrintWriter out=response.getWriter();
				
				//session.setAttribute("successful", "Transaction Successful");
				out.println("<html>"
						+ "<head>"
						+ "<body>"
						+ "<h2>Transaction Succesful</h2>"
						+ "<table>"
						+ "<tr>"
						+ "<td>Transaction Id:"+transaction1.getTransactionID()+"</td></tr>"
								+ "<tr><td>Transaction Date:"+transaction1.getTransactionDate()+"</td></tr>"
										+ "<tr><td>Transaction Amount:"+transaction1.getAmount()+"</td></tr></table>"
						+ "</body>"
						+ "</head>"
						+ "</html>"
	
					);
			}
			
			
			
			
		}
		
		
		
	}
	

}
