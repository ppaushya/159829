package org.capg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;
import org.capg.model.LoginBean;
import org.capg.model.Transaction;

public class LoginDaoImpl implements ILoginDao{

	@Override
	public Customer isValidLogin(LoginBean loginBean) {
		
		String sql="select * from customer where email=? and password=?";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
			pst.setString(1, loginBean.getUserName());
			pst.setString(2, loginBean.getUserPassword());
			
			ResultSet rs=pst.executeQuery();
			
			if(rs.next()) {
				Customer customer=new Customer();
				customer.setCustomerId(rs.getInt(1));
				customer.setFirstName(rs.getString(2));
				customer.setLastName(rs.getString(3));
				return customer;
			}
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	private Connection getMysqlDbConnection() {
		
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}


	@Override
	public boolean createCustomer(Customer customer) {
		int customerId=0;
		boolean flag=false;
	String sql="insert into customer(firstName, lastName, dateOfBirth, email, mobile, password)"+
						" values(?,?,?,?,?,?)";
		
	try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
		
		pst.setString(1, customer.getFirstName());
		pst.setString(2, customer.getLastName());
		pst.setDate(3, Date.valueOf(customer.getDateOfBirth()));
		pst.setString(4,customer.getEmailId());
		pst.setString(5,customer.getMobile());
		pst.setString(6,customer.getCustomerPwd());	
		
		int count=pst.executeUpdate();
		if(count>0)
			flag=true;
		
		if(flag) {
			String sqlMax="select max(customerId) from customer";
			try(PreparedStatement pst1=getMysqlDbConnection().prepareStatement(sqlMax)) {
				ResultSet rs= pst1.executeQuery();
				if(rs.next())
					customerId=rs.getInt(1);
				
				
				String sqlAdd="insert into address(addressline1,addressline2,city,state,pincode,customerId) values(?,?,?,?,?,?)";
				
				try(PreparedStatement pst2=getMysqlDbConnection().prepareStatement(sqlAdd)) {
					pst2.setString(1, customer.getAddress().getAddressLine1());
					pst2.setString(2, customer.getAddress().getAddressLine2());
					pst2.setString(3, customer.getAddress().getCity());
					pst2.setString(4, customer.getAddress().getState());
					pst2.setString(5, customer.getAddress().getPincode());
					pst2.setInt(6, customerId);
					
					int count1=pst2.executeUpdate();
					if(count1>0)
						flag=true;
					else
						flag=false;
					
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else {
			flag=false;
		}
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return flag;
	}


	@Override
	public Account createAccount(Account account) {
		
		Integer accountNo=null;
		
		String sqlaccNum="select max(accountNumber) from account";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sqlaccNum)){
			ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				accountNo=Integer.valueOf(rs.getInt(1));
				if(accountNo==0)
					accountNo=100000;
				else
					accountNo+=1;
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		account.setAccountNumber(accountNo);
		
		String sql="insert into account values(?,?,?,?,?,?)";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
			
			pst.setLong(1, accountNo);
			pst.setString(2, account.getAccountType().toString());
			pst.setDate(3,Date.valueOf(account.getOpeningDate()));
			pst.setDouble(4, account.getOpeningBalance());
			pst.setString(5, account.getDescription());
			pst.setInt(6, account.getCustomer().getCustomerId());
			int count=pst.executeUpdate();
			if(count>0)
				return account;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return null;
	}


	@Override
	public List<Account> getAccounts(int custId) {
		 List<Account> accounts= new ArrayList<>();
		String sql="select * from account where customerId=?";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) 
		{
			pst.setInt(1, custId);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Account account=new Account();
				account.setAccountNumber(rs.getInt(1));
				account.setAccountType(AccountType.valueOf(rs.getString(2)));
				accounts.add(account);
				
			}
			
			return accounts;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
	}


	@Override
	public Transaction addTransactionDetails(Transaction transaction) {
		String sql="insert into transaction(transactionDate, fromAccount,  toAccount, amount, description, transactionType, customerId) values(?,?,?,?,?,?,?)";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) 
		{
			pst.setDate(1, Date.valueOf(transaction.getTransactionDate()));
			pst.setInt(2, transaction.getFromAccount());
			pst.setInt(3, transaction.getToAccount());
			pst.setDouble(4,transaction.getAmount());
			pst.setString(5, transaction.getDescription());
			pst.setString(6,transaction.getTransactionType());
			pst.setInt(7,transaction.getCustomer().getCustomerId());
			
			int flag=pst.executeUpdate();
			if(flag>0)
			{
				String sql1="select transactionId,transactionDate, amount from transaction";
				
				try(PreparedStatement pst1=getMysqlDbConnection().prepareStatement(sql1)) 
				{
					Transaction transaction1=null;
					ResultSet rs=pst1.executeQuery();
					while(rs.next())
					{
						transaction1=new Transaction();
						transaction1.setTransactionID(rs.getInt(1));
						transaction1.setTransactionDate(rs.getDate(2).toLocalDate());
						System.out.println(rs.getDouble(3));
						transaction1.setAmount(rs.getDouble(3));
						
						
					}
					return transaction1;
					
				}
				
			
			}
			else return null;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}


	@Override
	public List<Account> getToAccounts(int custId) {
		
		 List<Account> accounts= new ArrayList<>();
		String sql="select * from account where customerId!=?";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) 
		{
			pst.setInt(1, custId);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Account account=new Account();
				account.setAccountNumber(rs.getInt(1));
				account.setAccountType(AccountType.valueOf(rs.getString(2)));
				accounts.add(account);
				
			}
			
			return accounts;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
	}


	@Override
	public double getCurrentBalance(int customerID, int accNo) {
		
		
		String sql1="select openingBalance from account where accountNumber=?";
		try(PreparedStatement pst1=getMysqlDbConnection().prepareStatement(sql1)) 
		{
			double currentBalance=0;
			pst1.setInt(1, accNo);
			ResultSet rs1=pst1.executeQuery();
			while(rs1.next())
			{
				currentBalance=rs1.getDouble(1);
				//System.out.println(currentBalance);
			}
		
		
				String sql="select fromAccount, toAccount, amount, transactionType from transaction where customerId=? and (fromaccount=? or toAccount=?)";
				try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) 
				{
					pst.setInt(1, customerID);
					pst.setInt(2, accNo);
					pst.setInt(3, accNo);
					ResultSet rs=pst.executeQuery();
					while(rs.next())
					{
						int fromAccount=rs.getInt(1);
						int toAccount=rs.getInt(2);
						double amount=rs.getDouble(3);
						String transactionType=rs.getString(4);
					
						if(fromAccount==accNo && transactionType.equals("Credit"))
						{
							currentBalance+=amount;
						}
						else if(fromAccount==accNo && transactionType.equals("Debit"))
						{
							currentBalance-=amount;
						}
						else if(toAccount==accNo && transactionType.equals("Debit"))
						{
							currentBalance+=amount;
						}
					}
					//System.out.println(currentBalance);
					return currentBalance;
					
			
			
			
		}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return 0;
	}
	
	@Override
	public List<Transaction> getAllTransactions(int custId, LocalDate fromDate, LocalDate toDate) {
		String sql="select * from transaction where customerId=? and transactionDate between ? and ?";
		List<Transaction> transactions=new ArrayList<>();
		try {
			PreparedStatement statement=getMysqlDbConnection().prepareStatement(sql);
			statement.setInt(1, custId);
			statement.setDate(2, Date.valueOf(fromDate));
			statement.setDate(3, Date.valueOf(toDate));
			ResultSet rs=statement.executeQuery();
			
			while(rs.next()) {
				String[] str=rs.getString(2).split("-");
				Transaction transaction=new Transaction();
				transaction.setTransactionID(rs.getInt(1));
				transaction.setTransactionDate(rs.getDate(2).toLocalDate());
				transaction.setFromAccount(rs.getInt(3));
				transaction.setToAccount(rs.getInt(4));
				transaction.setAmount(rs.getDouble(5));
				transaction.setDescription(rs.getString(6));
				transaction.setTransactionType(rs.getString(7));
				transaction.setCustomer(new Customer(rs.getInt(8)));
				transactions.add(transaction);
				
				
			}
			
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
		return transactions;
	}

}
