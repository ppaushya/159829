package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		
		PrintWriter out= response.getWriter();
		out.println("<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<meta charset=\"ISO-8859-1\">\r\n" + 
				"<title>PK Bank Payment Wallet</title>\r\n" + 
				"\r\n" + 
				"<link type=\"text/css\" rel=\"stylesheet\" href=\"styles/register.css\">\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<script>\r\n" + 
				"\r\n" + 
				"function passwordValidate()\r\n" + 
				"{\r\n" + 
				"	var flag=false;\r\n" + 
				"	var password=document.getElementById(\"custPwd\").value;\r\n" + 
				"	\r\n" + 
				"	var confirmPassword=document.getElementById(\"confirmCustPwd\").value;\r\n" + 
				"	if(password===confirmPassword)\r\n" + 
				"		{\r\n" + 
				"		document.getElementById(\"errPwd\").innerHTML=\"\";\r\n" + 
				"		flag=true;\r\n" + 
				"		}\r\n" + 
				"	else\r\n" + 
				"		\r\n" + 
				"		{\r\n" + 
				"		document.getElementById(\"errPwd\").innerHTML=\"The passwords don't match.\";\r\n" + 
				"		flag=false;\r\n" + 
				"			\r\n" + 
				"		}\r\n" + 
				"	return flag;\r\n" + 
				"	\r\n" + 
				"}\r\n" + 
				"</script>\r\n" + 
				"<form onsubmit=\"return passwordValidate()\" method=\"post\" action=\"register\" >\r\n" + 
				"<div id=\"register\">\r\n" + 
				"\r\n" + 
				"<div id=\"join\" >Join Money Bank</div>\r\n" + 
				"		<div id=\"tagline\">	The Better Way to Bank</div>\r\n" + 
				"\r\n" + 
				"	<div class=\"tablecnt\">\r\n" + 
				"		<table >\r\n" + 
				"			<tr>\r\n" + 
				"				<td class=\"headings\">Firstname <span style=\"color:red\">  *</span></td>\r\n" + 
				"				<td class=\"headings\">Lastname </td>\r\n" + 
				"				<td class=\"headings\">Date Of Birth <span style=\"color:red\">  *</span></td>\r\n" + 
				"			</tr>\r\n" + 
				"			<tr>\r\n" + 
				"				\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"text\" name=\"firstName\" size=\"20\" required >\r\n" + 
				"				</td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"text\" name=\"lastName\" size=\"20\">\r\n" + 
				"				</td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"date\" name=\"dateOfbirth\" required>\r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			\r\n" + 
				"			<tr>\r\n" + 
				"				<td class=\"headings\">Address Line 1 <span style=\"color:red\">  *</span></td>\r\n" + 
				"				<td class=\"headings\">Address Line 2</td>\r\n" + 
				"			</tr>\r\n" + 
				"		\r\n" + 
				"			<tr>\r\n" + 
				"				\r\n" + 
				"				<td>\r\n" + 
				"					<textarea rows=\"3\" cols=\"25\" name=\"addressline1\" required></textarea>\r\n" + 
				"				</td>\r\n" + 
				"				<td>\r\n" + 
				"					<textarea rows=\"3\" cols=\"25\" name=\"addressline2\"></textarea>\r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			\r\n" + 
				"			<tr>\r\n" + 
				"				<td class=\"headings\">City <span style=\"color:red\">  *</span></td>\r\n" + 
				"				<td class=\"headings\">State <span style=\"color:red\">  *</span></td>\r\n" + 
				"				<td class=\"headings\">Pincode <span style=\"color:red\">  *</span></td>\r\n" + 
				"			</tr>\r\n" + 
				"			\r\n" + 
				"			<tr>\r\n" + 
				"				\r\n" + 
				"				<td>\r\n" + 
				"					<select name=\"city\" required class=\"heading\">\r\n" + 
				"						<option value=\"Chennai\" >Chennai</option>\r\n" + 
				"						<option value=\"Hyderabad\" selected>Hyderabad</option>\r\n" + 
				"						<option value=\"Pune\" >Pune</option>\r\n" + 
				"						<option value=\"Delhi\">Delhi</option>\r\n" + 
				"						<option value=\"Mumbai\">Mumbai</option>\r\n" + 
				"						\r\n" + 
				"					</select>\r\n" + 
				"				</td>\r\n" + 
				"				\r\n" + 
				"				<td>\r\n" + 
				"					<select name=\"state\" required class=\"heading\">\r\n" + 
				"						<option value=\"Tamil NAdu\" >Tamil Nadu</option>\r\n" + 
				"						<option value=\"Telangana\" selected>Telangana</option>\r\n" + 
				"						<option value=\"Maharashtra\" >Maharashtra</option>\r\n" + 
				"						<option value=\"UP\">Uttar Pradesh</option>\r\n" + 
				"						\r\n" + 
				"						\r\n" + 
				"					</select>\r\n" + 
				"					\r\n" + 
				"				</td>\r\n" + 
				"				\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"text\" name=\"pincode\" size=\"20\" required pattern=\"[0-9]{6}\">\r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			\r\n" + 
				"			<tr>\r\n" + 
				"				<td class=\"headings\">Email ID <span style=\"color:red\">  *</span></td>\r\n" + 
				"				<td class=\"headings\">Mobile Number <span style=\"color:red\">  *</span></td>\r\n" + 
				"			</tr>\r\n" + 
				"			\r\n" + 
				"			<tr>\r\n" + 
				"				\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"email\" name=\"email\" size=\"20\" required pattern=\"[A-za-z._0-9]{1,}[@]{1}[a-z]{1,}[.]{1}[a-z]{2,3}\">\r\n" + 
				"				</td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"text\" name=\"mobile\" size=\"20\" required pattern=\"[0-9]{10}\">\r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"	\r\n" + 
				"			<tr>\r\n" + 
				"				<td class=\"headings\">Password:</td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"password\" name=\"custPwd\" id=\"custPwd\" size=\"20\" required>\r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			\r\n" + 
				"			<tr>\r\n" + 
				"				<td class=\"headings\">Confirm Password:</td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"password\" name=\"confirmCustPwd\" id=\"confirmCustPwd\" size=\"20\" required>\r\n" + 
				"					\r\n" + 
				"				</td>\r\n" + 
				"				<td>\r\n" + 
				"					<div id=\"errPwd\"></div>\r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			\r\n" + 
				"			\r\n" + 
				"			<tr>\r\n" + 
				"			\r\n" + 
				"				<td></td>\r\n" + 
				"				<td>\r\n" + 
				"				\r\n" + 
				"					<input type=\"submit\" name=\"register\" value=\"Register\" class=\"btnStyle\">\r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			\r\n" + 
				"			<tr>\r\n" + 
				"			<td=colspan=\"2\"><div id=\"successful\">"+ session.getAttribute("successful")+"</div></td></tr>\r\n" + 
				"			\r\n" + 
				"		</table>\r\n" + 
				"	\r\n" + 
				"	</div>\r\n" + 
				"</div>\r\n" + 
				"</form>\r\n" + 
				"\r\n" + 
				"</body>\r\n" + 
				"</html>");
	}

}
