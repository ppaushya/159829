package cap.org.demo;

import java.util.Scanner;

public class ArrayAssignment {
	
	int myArr[];
public void getArrayElements(int size)
	
	{
		myArr=new int[size];
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter "+size+" numbers:");
		for(int i=0;i<size;i++)
		{
			
			myArr[i]=scan.nextInt();
			
		}
		
	}
	public void BiggestElement(int size) 
	{
		int max=0;
		//myArr=new int[size];
		
			max=myArr[0];
			for(int j=0;j<size;j++)
			{
				if(max<myArr[j])
				{
					max=myArr[j];
				}
			}
		
		
			System.out.println("Maximum no:"+max);
		
		
	}
	public void SmallestElement(int size) 
	{
		
		//myArr=new int[size];
		
			int min=myArr[0];
			for(int j=0;j<size;j++)
			{
				if(min>myArr[j])
				{
					min=myArr[j];
				}
			}
		
		
			System.out.println("Minimum No:"+min);
		
		
	}
	public void evenNo(int size)
	{
		int sum=0;
		for(int i=0;i<size;i++)
		{
			if(myArr[i]%2==0)
			{
				System.out.print(myArr[i]+" ");
				sum=sum+myArr[i];
				
			}
		}
		System.out.println();
		System.out.println(sum);
	}
	

	public static void main(String[] args) {
		ArrayAssignment obj=new ArrayAssignment();
		int size=4;
		obj.getArrayElements(size);
		obj.BiggestElement(size) ;
		obj.SmallestElement(size) ;
		obj.evenNo(size);
		// TODO Auto-generated method stub

	}

}
