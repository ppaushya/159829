package cap.org.demo;

import java.util.Scanner;

public class Employee {
	 int empID;
	 String firstName;
	 String lastName;
	 int age;
	 int salary;
	 Scanner scan=new Scanner(System.in);
	public  void getData()
	{
		
		System.out.println("Enter the employee ID:");
		empID=scan.nextInt();
		System.out.println("Enter the employee FirstName:");
		firstName=scan.next();
		System.out.println("Enter the employee Last Name:");
		lastName=scan.next();
		System.out.println("Enter the Age:");
		age=scan.nextInt();
		System.out.println("Enter the salary:");
		salary=scan.nextInt();
		
		}
	public void printDetails()
	{
		System.out.print("EmpID: "+empID+" FirstName: "+firstName+" lastName: "+lastName+" Age: "+age+" salary: "+salary);
		
		
	}
	
	

}
