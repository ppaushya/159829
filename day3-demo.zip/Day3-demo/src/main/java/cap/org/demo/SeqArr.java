package cap.org.demo;

import java.util.Scanner;

public class SeqArr {
	int[][] arr;
	int m,n,o,p;
	int[][] arr1;
;
	public void getElements()
	{
		
		Scanner scan= new Scanner(System.in);
		System.out.println("Enter no of rows for first matrix:");
		m=scan.nextInt();
		System.out.println("Enter no of columns for first matrix:");
		n=scan.nextInt();	
		arr= new int[m][n];
		System.out.println("Enter the elements for first matrix:");
		for(int i=0;i<m;i++)
		{
			for(int j=0;j<n;j++)
			{
				arr[i][j]=scan.nextInt();
			}
		}
		System.out.println("Enter no of rows for second matrix:");
		o=scan.nextInt();
		System.out.println("Enter no of columns for second matrix:");
		p=scan.nextInt();	
		arr1=new int[o][p];
		System.out.println("Enter the elements for second matrix:");
			for(int i=0;i<o;i++)
			{
				for(int j=0;j<p;j++)
				{
					arr1[i][j]=scan.nextInt();
				}
			}
		}
			
		
		public void sum()
		{
			int[] sum= new int[m];
			int max=0;
			for(int i=0;i<m;i++)
			{
				for(int j=0;j<n;j++)
				{
					sum[i]=sum[i]+arr[i][j];
				}
			}
			for(int i=0;i<m-1;i++)
			{
				if(sum[i]>sum[i+1])
				{
					max=i+1;
				}
			}
			System.out.println("The subarray having min sum is:");
			for(int j=0;j<n;j++)
			System.out.print(arr[max][j]+" ");
			
		}
		
		
		public void sort()
		{
			int temp= 0;
			for(int k=0;k<m;k++)
			{
				for(int i=0;i<n;i++)
				{
					for(int j=i+1;j<n;j++)
					{
						if(arr[k][i]>arr[k][j])
						{
							temp=arr[k][i];
							arr[k][i]=arr[k][j];
							arr[k][j]=temp;
						}
					}
					
				}
			}
			for(int i=0;i<m;i++)
			{
				
				for(int j=0;j<n;j++)
				{
					
					System.out.print(arr[i][j]+"\t");
					
				}
				System.out.println();
			}
			
		}
		public void sequence()
		{
			int j,k,cnt=0;
			sort();
			for(j=0;j<m;j++)
			{
			for (int i=0;i<n-1;i++)
			{
				
				if(arr[j][i+1]-arr[j][i]>1)
				{
				System.out.println(arr[j][i]+1);
				break;
				
				}
				else
				{
					cnt++;
				
				}
			}	
			if(cnt==n-1)
				System.out.println(arr[j][n-1]+1);
			}
			
		}
	public void add()
	{
		int[][] c=new int[m][n];
			for(int i=0;i<m;i++)
			{
				for(int j=0;j<n;j++)
				{
					c[i][j]=arr[i][j]+arr1[i][j];
				}
			}
			for(int i=0;i<m;i++)
			{
				
				for(int j=0;j<n;j++)
				{
					
					System.out.print(c[i][j]+"\t");
					
				}
				System.out.println();
			}
	}
	public void mult()
	{
		int c[][]=new int[m][p];
		if(n==o)
		{
			for(int i=0;i<m;i++)
			{
				for(int j=0;j<p;j++)
				{
					for(int k=0;k<n;k++)
					
					c[i][j]=c[i][j]+arr[i][k]*arr1[k][j];
					
					System.out.print(c[i][j]+"\t");
				}
				
				System.out.println();
			}
			
		}
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SeqArr obj=new SeqArr();
		obj.getElements();
		obj.mult();
	}

}
