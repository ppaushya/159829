package cap.org.demo;

import java.util.Scanner;

public class MissingSequence {
		int myArr[];
		public void getArrayElements(int size)
		
		{
			myArr=new int[size];
			Scanner scan=new Scanner(System.in);
			System.out.println("Enter "+size+" numbers:");
			for(int i=0;i<size;i++)
			{
				
				myArr[i]=scan.nextInt();
				
			}
			
		}

		public void sort(int size)
		{
			int temp=0;
			for(int i=0;i<size;i++)
			{
				for(int j=i+1;j<size;j++)
				{
					if(myArr[i]>myArr[j])
					{
						temp=myArr[i];
						myArr[i]=myArr[j];
						myArr[j]=temp;
					}
				}
				
			}
			
			
		}
		public void sequence(int size)
		{
			int cnt=0,j,num,k;
		for (int i=0;i<size-1;i++)
		{
			j=i+1;
			if(myArr[j]==myArr[i]+1)
			{
			cnt++;
			
			}
			else break;
		}
				
		if(cnt==(size-1))
		{
			num=myArr[size-1]+1;
			System.out.println(num);
		}
		else
		{
			sort(size);
			for (int i=0;i<size-1;i++)
			{
				k=i+1;
				if(myArr[k]!=myArr[i]+1)
				{
				System.out.println(myArr[i]+1);
				break;
				
				}
				
			}
		}
			
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int size=4;
		MissingSequence obj=new MissingSequence();
		obj.getArrayElements(size);
		obj.sequence(size);

	}

}
