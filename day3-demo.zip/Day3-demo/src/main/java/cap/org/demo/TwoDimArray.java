package cap.org.demo;

import java.util.Scanner;

public class TwoDimArray {
	int[][] arr;
	int m,n;
	Scanner scan= new Scanner(System.in);
	public void getElements()
	{
		
		
		System.out.println("Enter no of rows:");
		m=scan.nextInt();
		System.out.println("Enter no of columns:");
		n=scan.nextInt();	
		if(n==m) {
			arr= new int[m][n];
			System.out.println("Enter the elements");
			for(int i=0;i<m;i++)
			{
				for(int j=0;j<n;j++)
				{
					arr[i][j]=scan.nextInt();
				}
			}
		}
		else
		{
			System.out.println("Number of rows and columns should be same");
		}
		
	}
	public void upper()
	{
		for(int i=0;i<m;i++)
		{
			
			for(int j=0;j<n;j++)
			{
				if(j>=i)
				System.out.print(arr[i][j]+"\t");
				else
					System.out.print("\t");
			}
			System.out.println();
		}
		
	}

	public void lower()
{
	for(int i=0;i<m;i++)
	{
		
		for(int j=0;j<n;j++)
		{
			if(j<=i)
			System.out.print(arr[i][j]+"\t");
			else
				System.out.print("\t");
		}
		System.out.println();
	}
	
}

	public void tran()
	{
		for(int i=0;i<m;i++)
		{
			
			for(int j=0;j<n;j++)
			{
				System.out.print(arr[j][i]+"\t");
			}
			System.out.println();
		}
	}
	
	


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TwoDimArray obj=new TwoDimArray();
		obj.getElements();
		//obj.upper();
		//obj.lower();
		obj.tran();
		

	}

}
