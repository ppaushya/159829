package cap.org.demo;

import java.util.Scanner;

public class ArraysDemo {
	
	int myArr[];
	public void getArrayElements(int size)
	
	{
		myArr=new int[size];
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter "+size+" numbers:");
		for(int i=0;i<size;i++)
		{
			
			myArr[i]=scan.nextInt();
			
		}
		
		//System.out.println("Reverse elements:");
		
			int temp=0;
		for(int i=0;i<=size/2-1;i++)
		{
			
				temp=myArr[i];
				myArr[i]=myArr[size-i-1];
				myArr[size-i-1]=temp;
		
		}
		
					
		
		
	}
	
	public void sort(int size)
	{
		int temp=0;
		for(int i=0;i<4;i++)
		{
			for(int j=i+1;j<size;j++)
			{
				if(myArr[i]>myArr[j])
				{
					temp=myArr[i];
					myArr[i]=myArr[j];
					myArr[j]=temp;
				}
			}
			
		}
		System.out.println("The elements are");
		
		for(int i=0;i<size;i++)
		{
			System.out.println(myArr[i]);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*int[] num= {1,2,3,4,5,7,6,8,9,0};
		int num1[]=new int[10];
		short sh=14;
		double pi=3.1415;
		num[0]=1;
		num[1]=sh;
		num[5]=2;
		num[6]=(int)pi;
		num[9]=3;
		for(int i=0;i<10;i++)
		{
			System.out.println(num[i]);
		}
*/
		ArraysDemo obj=new ArraysDemo();
		obj.getArrayElements(5);
		obj.sort(5);
	}

}
