package cap.org.demo;

public class varArg {

	public void printData(int ... arr)
	{
		for(int value: arr)
			System.out.println(value);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {1,2,3,4};
		varArg obj=new varArg();
		obj.printData(arr);
 
	}

}
