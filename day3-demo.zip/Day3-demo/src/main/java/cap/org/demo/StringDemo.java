package cap.org.demo;

import java.util.Scanner;

public class StringDemo {
	String myStr[];
	public void getString(int size)
	{
		myStr=new String[size];
		System.out.println("Enter "+size+" strings");
		Scanner scan=new Scanner(System.in);
		for(int i=0;i<size;i++)
		{
			myStr[i]=scan.nextLine();
		}
		
	}
	public void reverse(int size)
	{
		String temp;
		for(int i=0;i<=size/2-1;i++)
		{
			
				temp=myStr[i];
				myStr[i]=myStr[size-i-1];
				myStr[size-i-1]=temp;
					
		}
		for(int i=0;i<size;i++)
		{
			System.out.println(myStr[i]);
		}
		
	}
	public void sort(int size)
	{
		String temp;
		for(int i=0;i<4;i++)
		{
			for(int j=i+1;j<size;j++)
			{
				if(myStr[i].compareToIgnoreCase(myStr[j])>1)
				{
					temp=myStr[i];
					myStr[i]=myStr[j];
					myStr[j]=temp;
				}
			}
			
		}
		
		
		for(int i=0;i<size;i++)
		{
			System.out.println(myStr[i]);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int size=4;
		StringDemo obj=new StringDemo();
		obj.getString(size);
		obj.sort(size);
		
	}

}
