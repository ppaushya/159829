package cap.org.demo;

public class MainClass {

	Employee employees[];
	public void accept(int size)
	{
		employees= new Employee[size];
		for(int i=0;i<size;i++)
		{
			employees[i]= new Employee();
			employees[i].getData();
			
		}
	}
	public void print()
	{
		
		for(int i=0;i<employees.length;i++)
		{
			System.out.println();
		employees[i].printDetails();
		}
	}
	public void sortByEMpID()
	{
		
			Employee temp=new Employee();
			for(int i=0;i<employees.length;i++)
			{
				for(int j=i+1;j<employees.length;j++)
				{
					if(employees[i].empID>employees[j].empID)
					{
						temp=employees[i];
						employees[i]=employees[j];
						employees[j]=temp;
					}
				}
				
			}
			
			print();

	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MainClass obj=new MainClass();
		obj.accept(2);
		obj.sortByEMpID();
	}

}
