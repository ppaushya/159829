package org.cap.demo;

public class Assignments1 {

	int[] arr;
	
	int k=1;
	public void findprime(int num)
	{
		arr=new int[num];
		arr[0]=2;
		for(int i=3;i<num;i++)
		{
			int cnt=0;		
			for(int j=2;j<i;j++)
			{
				if(i%j==0)
				{
					cnt++;
				}
			}
			if(cnt==0)
			{
				arr[k]=i;
				k++;
			}
			
		}
		for(int i=0;i<k;i++)
		{
			System.out.println(arr[i]);
		}
	}
	public void primefactors(int num)
	{
		findprime(num);
		for(int i=0;i<k;)
		{
			if(num%arr[i]==0)
			{
				System.out.print(arr[i]+" ");
				num=num/arr[i];
				continue;
			}
			else
			{
				i++;
			}
		}
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Assignments1 obj=new Assignments1();
		obj.primefactors(20);
		

	}

}
