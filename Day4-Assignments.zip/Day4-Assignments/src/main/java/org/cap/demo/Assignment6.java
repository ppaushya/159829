package org.cap.demo;

import java.util.Scanner;

public class Assignment6 {
	
	public int FirstFactorial(int num)
	{
		int fact;
		if(num==0|| num==1)
			return 1;
		else 
		{
			fact=num*FirstFactorial(num-1);
		}
		return fact;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int fact=0,num;
		System.out.println("Enter the number whose factorial is to be found:");
		Scanner scan= new Scanner(System.in);
		num=scan.nextInt();
		Assignment6 obj= new Assignment6();
		fact=obj.FirstFactorial(num);
		System.out.println(fact);
	}

}

