package org.cap.demo;

import java.util.Scanner;

public class Assignment8 {
	String str,str1;
	public void getString()
	{
		System.out.println("Enter the first string:");
		Scanner scan=new Scanner(System.in);
		str= scan.nextLine();
		System.out.println("Enter the second string:");
		str1= scan.nextLine();
		scan.close();
		
	}
	public void anagram()
	{
		int a[]=new int[26];
		int b[]=new int[26];
		for(int i=0;i<str.length();i++)
		{
			a[(str.charAt(i)-97)]++;
		}
		for(int i=0;i<str1.length();i++)
		{
			b[(str1.charAt(i)-97)]++;
		}
		for(int i=0;i<26;i++)
		{
			if(a[i]!=b[i])
			{
				System.out.println("The given strings are not anagram");
				break;
			}
			
		}
		System.out.println("The given strings are anagram");
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Assignment8 obj=new Assignment8();
		obj.getString();
		obj.anagram();
	}

}
