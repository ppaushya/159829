package org.cap.demo;

public class StringMethods {

	
	public static void main(String[] args) {
		
		String str="Annapoorna";
		String str3="Annapoorna";
		char[] str2={'a','b','c','d'};
		String str1="";
		System.out.println(str.charAt(4));
		System.out.println(str.codePointAt(0));
		System.out.println(str.compareTo("Annapoorna"));
		System.out.println(str.compareToIgnoreCase("annapoorna"));
		System.out.println(str.concat(" Bhanu"));
		System.out.println(str.contains("poorna"));
		System.out.println(str.contentEquals("Annapoorna"));
		str1=String.copyValueOf(str2);
		System.out.println(str1);
		str1=String.copyValueOf(str2,1,2);
		System.out.println(str1);
		System.out.println(str.endsWith("na"));
		System.out.println(str.equals(str3));
		System.out.println(str.equalsIgnoreCase(str3));
		
		
		// TODO Auto-generated method stub

	}

}
