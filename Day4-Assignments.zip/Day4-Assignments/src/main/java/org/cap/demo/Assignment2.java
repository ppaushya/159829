package org.cap.demo;

public class Assignment2 {

	String str;
	
		public void AlphabetSoup(String str)
		{
			char[] ch=new char[str.length()];
			char temp;
			for(int i=0;i<str.length();i++)
			{
				ch[i]=str.charAt(i);
			}
			for(int i=0;i<ch.length;i++)
			{
				for(int j=i+1;j<ch.length;j++)
				{
					if(ch[i]>ch[j])
					{
						temp=ch[i];
						ch[i]=ch[j];
						ch[j]=temp;
					}
				}
				
			}
			for(int i=0;i<ch.length;i++)
			{
				System.out.print(ch[i]);
			}
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Assignment2 obj=new Assignment2();
		obj.str=new String("hello");
		obj.AlphabetSoup(obj.str);
		

}
}
