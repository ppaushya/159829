package org.cap.demo;

import java.util.Scanner;

public class Assignment3457 {

	String str;
	//String str1;
	public void getString()
	{
		System.out.println("Enter the string:");
		Scanner scan=new Scanner(System.in);
		str= scan.nextLine();
		
		scan.close();
		
	}
		public String LetterCapitalize(String str)
	{
			int a=0;
			char[] ch=new char[str.length()];
			for(int i=0;i<str.length();i++)
			{
				ch[i]=str.charAt(i);
				
			}
		for(int i=0;i<str.length()-1;i++)
		{
			if(ch[i]==' ' && ch[i+1]==' ')
			{
				System.out.println("Two consecutive spaces are not allowed");
				System.exit(0);
			}
		}
		for(int i=0;i<str.length()-1;i++)
			{
				if(ch[0]!=' ')
				{
					if((int)(ch[0])>=97 && (int)(ch[0])<=122)
					{
						ch[0]=(char) (ch[0]-32);
					}
				}
				
				if(ch[i]==' ')
				{
					a=ch[i+1];
					if(a>=97 && a<=122)
					{
						ch[i+1]=(char) (ch[i+1]-32);
					}
				}
			
		
		}
		String str2= new String(ch);
		return str2;
			
	}
		public String LetterChanges(String str)
		{
			int a=0;
			char[] ch=new char[str.length()];
			for(int i=0;i<str.length();i++)
			{
				ch[i]=str.charAt(i);
				
			}
			for(int i=0;i<str.length();i++)
			{
				/*if(ch[i]=='a' || ch[i]=='e' || ch[i]=='i' ||  ch[i]=='o' || ch[i]=='u'  )
				{
					ch[i]=(char)(ch[i]-32);
				}
				else if(ch[i]=='A' || ch[i]=='E'|| ch[i]=='I' || ch[i]=='O' || ch[i]=='U')
				{
					ch[i]=ch[i];
				}*/
				if(ch[i]<65 || (ch[i]>90 && ch[i]<97)|| ch[i]>122)
				{
					ch[i]=ch[i];
				}
			else if(ch[i]=='z') ch[i]='a';
					else if(ch[i]=='Z') ch[i]='A';
					else
					{
						ch[i]=(char)(ch[i]+1);
					}
				
			}
			for(int i=0;i<ch.length;i++)
			{
				if(ch[i]=='a' || ch[i]=='e' || ch[i]=='i' ||  ch[i]=='o' || ch[i]=='u'  )
				{
					ch[i]=(char)(ch[i]-32);
				}
			}
			String str2=new String(ch);
			return str2;
			
		}
		public String ReverseString(String str)
		{			char ch[]=new char[str.length()];
			for(int i=0;i<str.length();i++)
			{
				ch[i]=str.charAt(str.length()-i-1);
				
			}
			String str1=new String(ch);
			return str1;
		}
		
		public String LongestWord(String str) {
			char[] ch=new char[str.length()];
			char[] ch2=new char[str.length()];
			int temp=0,temp2=0,x=0,a1=0,a=0;
			for(int i=0;i<str.length();i++)
				ch[i]=str.charAt(i);
			
			for(int i=0;i<ch.length;i++) {
				if(i==0 || ch[i]!=' '&&ch[i-1]==' ')x=i;
				if(ch[i]!=' ') {temp++;}
				if(ch[i]==' ' || i==ch.length-1) {if(temp2<=temp){temp2=i;a1=x;}temp=0;}
			}

			System.out.print("Longets word is: ");
			for(int i=a1;i<=temp2;i++)
			{
				ch2[a]=ch[i];
				a++;
			}
			String str2=new String(ch2);
			return str2;
		}
		
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
			Assignment3457 obj=new Assignment3457();
			obj.getString();
			String s1=obj.LongestWord(obj.str);
			System.out.println(s1);
			
	}

}
