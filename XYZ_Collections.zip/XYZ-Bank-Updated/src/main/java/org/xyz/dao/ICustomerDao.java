package org.xyz.dao;

import java.util.List;
import java.util.Map;

import org.xyz.model.Account;
import org.xyz.model.Customer;
import org.xyz.model.Transaction;

public interface ICustomerDao {
	public abstract List<Customer> getAllCustomers();
	public abstract void createCustomer(Customer customer);
	
	public abstract void addAccountDetails(Customer customers, Account account);
	

	public abstract void addTransactionDetails(Account account, Transaction transaction);
	public abstract List<Transaction> getTransactionDetails(Account account);
}
