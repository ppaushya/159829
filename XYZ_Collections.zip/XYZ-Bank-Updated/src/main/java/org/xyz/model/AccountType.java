package org.xyz.model;

public enum AccountType {

	SAVINGS,RD,FD,CURRENT;

}
