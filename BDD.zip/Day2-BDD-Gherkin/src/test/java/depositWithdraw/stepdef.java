package depositWithdraw;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;

import java.time.LocalDate;

import org.cap.dao.IAccountDao;
import org.cap.exception.InvalidAmountException;
import org.cap.exception.NoAccountException;
import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.cap.service.AccountServiceImpl;
import org.cap.service.IAccountService;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {

	
	@Rule
	public ExpectedException thrown=ExpectedException.none();
	private double balance;
	
	private IAccountService accountService;
	
	private Customer customer;
	private Account account;
	@Mock
	private IAccountDao accountDao;
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		accountService=new AccountServiceImpl(accountDao);
		
	}
	@Given("^Customer and Account details$")
	public void customer_and_Account_details() throws Throwable {
	   
		
		Address address=new Address("23 North avvenue","Chennai");
		 customer=new Customer("Tom", "Jerry", address);
		account= new Account(10001, customer, 1000);
	    
	}

	@When("^Valid Amount$")
	public void valid_Amount() throws Throwable {
	    int amount=1000;
		assertFalse(amount<0);
	    
	}

	@Then("^Deposit or Withdraw$")
	public void deposit_or_Withdraw() throws Throwable {
	    int amount=1000;
		Transaction transaction=new Transaction(1, LocalDate.now(), amount, "hello", "Deposit", account, null);
	   Mockito.when(accountDao.depositOrWithdraw(transaction)).thenReturn(true);
	   
	   boolean flag=accountService.depositOrWithdraw(transaction);
	   
	   Mockito.verify(accountDao).depositOrWithdraw(transaction);
	}

	@Given("^Valid Customer details$")
	public void valid_Customer_details() throws Throwable {
		Address address=new Address("23 North avvenue","Chennai");
		customer=new Customer("Tommy", "Jerry", address);
	    
	}

	@When("^No Account$")
	public void no_Account() throws Throwable {
	    account=null;
	}

	@Then("^throw error message 'You dont have any Account'$")
	public void throw_error_message_You_dont_have_any_Account() throws Throwable {
		Transaction transaction=new Transaction(1, LocalDate.now(), 1000, "hello", "Deposit", account, null);
		accountService.depositOrWithdraw(transaction);
		thrown.expect(NoAccountException.class);
		thrown.expectMessage("You dont have any Account");
		
		
		
	}

	@Given("^Valid Customer Details$")
	public void valid_Customer_Details() throws Throwable {
		Address address=new Address("23 North avvenue","Chennai");
		customer=new Customer("Tommy", "Jerry", address);
	}

	@Given("^Amount$")
	public void amount() throws Throwable {
	    int amount=0;
	}

	@When("^Invalid Amount$")
	public void invalid_Amount() throws Throwable {
		 int amount=0;
		assertFalse(amount<0);
	}

	@Then("^throw error message 'Invalid Amount!'$")
	public void throw_error_message_Invalid_Amount() throws Throwable {
		thrown.expect(InvalidAmountException.class);
		thrown.expectMessage("Invalid Amount!");
	}


}
