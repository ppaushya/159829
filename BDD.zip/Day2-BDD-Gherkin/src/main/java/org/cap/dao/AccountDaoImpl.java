package org.cap.dao;

import org.cap.model.Account;
import org.cap.model.Transaction;

public class AccountDaoImpl implements IAccountDao {

	@Override
	public boolean createAccount(Account account) {
		
		return true;
	}

	@Override
	public boolean depositOrWithdraw(Transaction transaction) {
		// TODO Auto-generated method stub
		return true;
	}

}
