package org.cap.exception;

public class NoAccountException extends Exception {

	public  NoAccountException(String str)
	{
		super(str);
	}
}
