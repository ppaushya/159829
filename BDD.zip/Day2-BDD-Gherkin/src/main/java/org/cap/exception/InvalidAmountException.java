package org.cap.exception;

public class InvalidAmountException extends Exception {

	public InvalidAmountException(String str)
	{
		super(str);
	}
}
