package org.cap.service;

import org.cap.exception.InsufficientbalanceException;
import org.cap.exception.InvalidAmountException;
import org.cap.exception.NoAccountException;
import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;

public interface IAccountService {

	public Account createAccount(Customer customer,double balance) throws InsufficientbalanceException;
	
	public boolean depositOrWithdraw(Transaction transaction) throws InvalidAmountException, NoAccountException;
}
