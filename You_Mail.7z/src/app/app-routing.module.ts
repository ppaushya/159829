import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InboxComponent } from './inbox/inbox.component';
import { EmailComponent } from './Email/Email.component';

const routes: Routes = [
  {path:'', pathMatch:"full", redirectTo:"login"},
  {path:'login',component:EmailComponent},
  {path: 'inbox', component: InboxComponent  }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
