import { Component, OnInit } from '@angular/core';
import { Login } from '../login';
import { Email } from '../email';
import { AppService } from '../app.service';

@Component({
  
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.css']
})
export class InboxComponent implements OnInit {

  emails:Email[]=[];
  email:Email=new Email();
  id:string;
  flag:Boolean;

  constructor(private _service:AppService) { 

    this.id= this._service.sendMail();
    this.email.receiverEmailId=this.id;
    this._service.getMails(this.email).subscribe(emails=>
      {
        console.log(emails);
        this.emails=emails}
        );
  }

  ngOnInit() {
    
  }

  verificationDone()
  {
    this._service.verificationDone(this.email).subscribe(flag=>this.flag=flag);
  }



}
