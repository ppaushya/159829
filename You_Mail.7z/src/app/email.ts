export class Email
{
    serialNo: number;
    message:string;
    imageUrl:string;
    receiverEmailId:string;
    senderEmailId:string;

}