import { Component, OnInit } from '@angular/core';
import { Login } from '../login';
import { AppService } from '../app.service';
import { Router } from '@angular/router';

@Component({
  
  templateUrl: './Email.component.html',
  styleUrls: ['./Email.component.css']
})
export class EmailComponent implements OnInit {

  login:Login=new Login();

  constructor(private _service:AppService, private _router:Router) { }

  ngOnInit() {
  }

  validLogin()
  {
    this._service.validLogin(this.login).subscribe(flag=>
      {
        if(flag)
        {
          this._service.getEmail(this.login.emailId);
          this._router.navigate(['/inbox'])
        }
        else{
          this._router.navigate(['/login'])
        }
      }
      
      )
  }


}
