import { Injectable } from '@angular/core';
import { Login } from './login';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Email } from './email';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  private url:string="http://localhost:8086/capstore/api/v1/youMail";
  constructor(private _http:HttpClient) { 

  }

  getMails(email:Email):Observable<Email[]>{
    let url=this.url+"/email";
    return this._http.post<Email[]>(url,email);
  }

  validLogin(login:Login):Observable<Boolean>
  {
     return this._http.post<Boolean>(this.url,login)  
  }

  mail:string;
  getEmail(mail:string){
    this.mail= mail;
  }

  sendMail():string{
    return this.mail;
  }

  verificationDone(email:Email):Observable<Boolean>

  {
    return this._http.post<Boolean>("http://localhost:8086/capstore/api/v1/emailVerificationDone",email)
  }
}
