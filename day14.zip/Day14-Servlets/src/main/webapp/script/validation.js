function validate(){
	var bool=false;
	
	var userName=document.getElementById('userName').value;
	var userPwd=document.getElementById('userPwd').value;
	
	
	if(userName==""||userName==null){
		document.getElementById('userErrMsg').innerHTML="*Please enter UserName.";
		bool=false;
	}else if(userPwd==""||userPwd==null){
		document.getElementById('pwdErrMsg').innerHTML="*Please enter Password.";
		document.getElementById('userErrMsg').innerHTML="";
		bool=false;
	}else{
		document.getElementById('pwdErrMsg').innerHTML="";
		document.getElementById('userErrMsg').innerHTML="";
		bool=true;
	}
	
	return bool;
}