import { Component } from "@angular/core";


@Component({
    templateUrl:'./fundsTransfer.component.html',
    styleUrls:['./fundsTransfer.component.css']
    
})
export class  FundsTransferComponent
{

    
} 
