import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { MainPageComponent } from './mainPage/mainPage.component';
import { CreateAccountComponent } from './createAccount/createAccount.component';
import { DepositWithdrawComponent } from './despositWithdraw/depositWithdraw.component';
import { LoginServiceComponent } from './login/login.service';
import { HttpClientModule } from '@angular/common/http';
import { FundsTransferComponent } from './fundsTransfer/fundsTransfer.component';

@NgModule({
  declarations: [
    AppComponent, LoginComponent, MainPageComponent, CreateAccountComponent, DepositWithdrawComponent, FundsTransferComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      { path:'login' , component: LoginComponent},

     { path:'mainPage' , component: MainPageComponent  },
       { path: '',  pathMatch:'full', redirectTo: '/login' },
       {path: 'createAccount', component: CreateAccountComponent},
       { path:'depositWithdraw' , component: DepositWithdrawComponent},
        {path:'fundsTransfer', component: FundsTransferComponent}

    ])
  ],
  providers: [LoginServiceComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
