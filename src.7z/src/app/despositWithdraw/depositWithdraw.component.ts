import { Component } from "@angular/core";
import { Account } from "../createAccount/account";



@Component({
    templateUrl:'./depositWithdraw.component.html',
    styleUrls:['./depositWithdraw.component.css']
    
})
export class  DepositWithdrawComponent
{
    accounts: Account[]=[];
    


       
} 
