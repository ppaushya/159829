import { Injectable } from "@angular/core";
import { HttpClient,  HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LoginComponent } from "./login.component";
import { Login } from "./login";



const header=new HttpHeaders({ 'Content-Type': 'application/json'})

@Injectable()
export class LoginServiceComponent
{
    private _loginUrl="http://localhost:8080/ParallelProjectSpring/project/login";


    constructor(private _http: HttpClient){}

    isValidLogin(login: Login):Observable<Login>
    {
       // console.log(this._http.get<boolean>(this._loginUrl+"/"+login.userName+"/"+login.userPassword))
       return this._http.get<Login>(this._loginUrl+"/"+login.userName+"/"+login.userPassword);
    }

}