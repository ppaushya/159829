import { Component } from "@angular/core";
import { Login } from "./login";
import {  LoginServiceComponent } from "./login.service";
import { Router } from "@angular/router";


@Component({
    templateUrl:'./login.component.html',
    styleUrls:['./login.component.css']
    
})
export class  LoginComponent
{
    login:Login = new Login("","");
    
    login1:Login= new Login("","");
    validLogin:boolean;
    constructor(private _loginService:LoginServiceComponent, private _router:Router)
    {

    }

    isValidLogin():void{

        
        this._loginService.isValidLogin(this.login).subscribe(login => this.login1=login)
       console.log(this.login1);
        if(this.login1.userName!=null)
        {
            
            this._router.navigate(['/mainPage']);
        }
        else
        {
            
            this._router.navigate(['/login']);
        }
        
    }



} 
