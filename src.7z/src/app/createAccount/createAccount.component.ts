import { Component } from "@angular/core";
import { Account } from "./account";


@Component({
    templateUrl:'./createAccount.component.html',
    styleUrls:['./createAccount.component.css']
    
})
export class  CreateAccountComponent
{
   account:Account=new Account();
    
} 
