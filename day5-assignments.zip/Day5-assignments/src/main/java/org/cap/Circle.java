package org.cap;
public class Circle implements ConstantEx{

	public float area(float r)
	{
		float a= pi*r*r;
		return a;
	}
}
