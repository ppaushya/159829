package org.cap;

import java.util.Scanner;

public class PG_Students implements Student {
	int stud_id;
	public void getStud_ID()
	{
		Scanner sc= new Scanner(System.in);
		stud_id= sc.nextInt();
		
	}
	public  void Display_Grade(int stud_id)
	{
		System.out.println("The Grade of "+stud_id+" is: A");
	}
	public  void Attendance(int stud_id)
	{
		System.out.println("The Attendance of "+stud_id+" is: 90");
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	}

}
