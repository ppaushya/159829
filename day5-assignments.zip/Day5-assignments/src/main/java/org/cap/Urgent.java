package org.cap;

public class Urgent extends Trunkcall{

final int  cpm=4;
	
	public Urgent() {
		
	}
	public Urgent(float duration) {
		super(duration);
		
	}

	public void charges(float duration)
	{
		float totcharges=duration*cpm;
		System.out.println("Total charges="+totcharges);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Trunkcall ur=new Urgent(20);
		ur.charges(ur.duration);


	}

}
