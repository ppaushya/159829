package org.cap;

public class SalariedWorker extends Worker {
	 final int hours=40;
	public SalariedWorker()
	{
		
	}
	
	public SalariedWorker(String name,float salaryRate)
	{
		super(name,salaryRate);
	}
	
	public double calculateSalary(int hours)
	{
		double sal=40*salaryRate;
		return sal;
	}

	public int getDetails() {
		return 0;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Worker sl=new SalariedWorker("ahsdg",100);
		double sal=sl.calculateSalary(40);
		System.out.println(sal);
	}

}
