package org.cap;
public interface ConstantEx {
	final static float pi=3.14f;
	public abstract float area(float a);
	
	

}
