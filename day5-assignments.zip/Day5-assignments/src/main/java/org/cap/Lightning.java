package org.cap;

public class Lightning extends Trunkcall {
	
final int  cpm=6;
	
	public Lightning() {
		
	}
	public Lightning(float duration) {
		super(duration);
		
	}

	public void charges(float duration)
	{
		float totcharges=duration*cpm;
		System.out.println("Total charges="+totcharges);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Trunkcall li= new  Lightning(20);
		li.charges(li.duration);

	}

}
