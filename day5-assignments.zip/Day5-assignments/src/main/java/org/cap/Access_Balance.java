package org.cap;

import Balance.Account;

public class Access_Balance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account acc= new Account();
		acc.Display_Balance();
	}

}
