package org.cap;

public abstract class Trunkcall {
	float duration;
	public Trunkcall() {
		
	}
	
	public Trunkcall(float duration) {
		super();
		this.duration = duration;
	}

	public abstract void charges(float dur);
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
