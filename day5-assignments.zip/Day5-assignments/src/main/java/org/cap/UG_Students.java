package org.cap;

import java.util.Scanner;

public class UG_Students implements Student {

	int stud_id;
	public void getStud_ID()
	{
		Scanner sc= new Scanner(System.in);
		stud_id= sc.nextInt();
		
	}
	public  void Display_Grade(int stud_id)
	{
		System.out.println("The Grade of "+stud_id+" is: B");
	}
	public  void Attendance(int stud_id)
	{
		System.out.println("The Attendance of "+stud_id+" is: 60");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PG_Students obj=new PG_Students();
		obj.getStud_ID();
		obj.Display_Grade(obj.stud_id);
		obj.Attendance(obj.stud_id);
		UG_Students obj1=new UG_Students();
		obj1.getStud_ID();
		obj1.Display_Grade(obj1.stud_id);
		obj1.Attendance(obj1.stud_id);
	}

}
