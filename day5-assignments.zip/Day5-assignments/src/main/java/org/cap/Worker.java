package org.cap;

public abstract class Worker {
	String name;
	float salaryRate;
	public Worker()
	{
		
	}
	
	
	public Worker(String name, float salaryRate) {
		super();
		this.name = name;
		this.salaryRate = salaryRate;
	}


	public abstract double calculateSalary(int hours);
	public abstract int getDetails();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		

	}

}
