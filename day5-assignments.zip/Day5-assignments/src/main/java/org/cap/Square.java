package org.cap;
public class Square implements ConstantEx{
	public float area(float a)
	{
		float area= a*a;
		return area;
	}

	public static void main(String[] args)
	{
		Circle cir=new Circle();
		
		float ar=cir.area(10);
		Square sq= new Square();
		float ar1=sq.area(10);
		System.out.println(ar+"  "+ar1);
	}
}