package org.cap;

public class Ordinary extends Trunkcall {
	
	final int  cpm=2;
	
	public Ordinary() {
		
	}
	public Ordinary(float duration) {
		super(duration);
		
	}

	public void charges(float duration)
	{
		float totcharges=duration*cpm;
		System.out.println("Total charges="+totcharges);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Trunkcall or=new Ordinary(20);
		or.charges(or.duration);

	}

}
