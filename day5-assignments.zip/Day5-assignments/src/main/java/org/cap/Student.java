package org.cap;

public interface Student {
	
	public abstract void Display_Grade(int stud_id);
	public abstract void Attendance(int stud_id);

}
