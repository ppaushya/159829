package org.cap;

import java.util.Scanner;

public class DailyWorker extends Worker {
	int hours;
	//int days;
	public DailyWorker()
	{
		
	}
	
	
	/*public DailyWorker(String name,float salaryRate,int hours) {
		super(name,salaryRate);
		this.hours = hours;
	}*/
	

	public double calculateSalary(int hours)
	{
		double sal=hours*5*salaryRate;
		return sal;
	}
	public DailyWorker(String name, float salaryRate, int hours) {
		super(name, salaryRate);
		this.hours = hours;
	}


	public DailyWorker(int hours) {
		super();
		this.hours = hours;
	}


	public int getDetails()
	{
		
		return hours;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Worker wor=new DailyWorker("Ramesh",100,8);
		double sal=wor.calculateSalary(wor.getDetails());
		System.out.println(sal);
		
	}

}
