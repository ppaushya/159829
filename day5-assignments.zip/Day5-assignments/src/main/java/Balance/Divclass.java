package Balance;

public class Divclass implements DivMul {

	public void division(float a,float b)
	{
		float div= (float)(a/b);
		System.out.println(div);
	}
	
	public void modules(float a,float b)
	{
		float mod= a%b;
		System.out.println(mod);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Divclass div= new Divclass();
		div.division(5, 2);
		div.modules(5, 2);
	}

}
