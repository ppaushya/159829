package Balance;

public class Account {

	public void Display_Balance()
	{
		System.out.println("The balance is : 10000");
	}
}
