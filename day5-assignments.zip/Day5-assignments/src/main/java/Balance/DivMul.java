package Balance;

public interface DivMul {
	
	public abstract void division(float a, float b);
	public abstract void modules(float a, float b);

}
