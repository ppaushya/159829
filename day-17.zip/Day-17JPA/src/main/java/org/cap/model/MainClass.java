package org.cap.model;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {
	
	
	
	public static void main(String[] args)
	
	{
		
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("jpademo");
		EntityManager em=emf.createEntityManager();
		
		EntityTransaction transaction=em.getTransaction();
		transaction.begin();
		Employee employee=new Employee("Annapoorna","Bhanu",100000);
		
		Employee employee1=new Employee();
		employee1.setFirstName("Nihaa");
		employee1.setLastName("donga");
		employee1.setSalary(100000);
		employee1.setDateOfJoining(new Date());
		em.persist(employee);
		
		
		
		em.persist(employee);
		em.persist(employee1);
		transaction.commit();
		
	}

}
