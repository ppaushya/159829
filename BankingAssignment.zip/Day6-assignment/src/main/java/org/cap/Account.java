package org.cap;

import java.time.LocalDate;
import java.util.Date;

public class Account {
	
	private long accountNo;
	private AccountType accountType;
	private LocalDate openingDate;
	private int openingBal;
	//private int currentBal;
	/*
	public int getCurrentBal() {
		return currentBal;
	}

	public void setCurrentBal(int currentBal) {
		this.currentBal = currentBal;
	}
*/
	public Account()
	{
		
	}
	
	public Account(long accountNo, AccountType accountType, LocalDate openingDate, int openingBal) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.openingDate = openingDate;
		this.openingBal = openingBal;
		//this.currentBal = currentBal;
	}

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public AccountType getAccountType() {
		return accountType;
	}

	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}

	public LocalDate getOpeningDate() {
		return openingDate;
	}

	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}

	public int getOpeningBal() {
		return openingBal;
	}

	public void setOpeningBal(int openingBal) {
		this.openingBal = openingBal;
	}
	
	
	
	

}