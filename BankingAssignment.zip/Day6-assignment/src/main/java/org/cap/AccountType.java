package org.cap;

public enum AccountType {
	SAVINGS,RD,FD,CURRENT;
}
