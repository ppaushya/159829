package org.cap;

import java.time.LocalDate;
import java.time.Month;
import java.util.Date;
import java.util.Scanner;

public class MainClass1 {

	public static AccountType selectAccountType(int c)
	{
		//AccountType accountType;
		if(c==1)
		{
			return AccountType.SAVINGS;
		}
		else if(c==2)
		{
			return AccountType.RD;
		}
		else if(c==3)
		{
			return AccountType.FD;
		}
		else if(c==4)
		{
			return AccountType.CURRENT;
		}
		else {
			 System.out.println("Type Invalid!");
		}
		return null;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int custno=100000;
		Scanner scan= new Scanner(System.in);
		Validate validate=new Validate();
		Customer[] cust=new Customer[10];
		Address[] address=new Address[10];
		Account[][] account= new Account[10][4];
		Transactions[] transactions=new Transactions[100];
		int index1=0;
		for (int i=0;i<10;i++)
		{
			for(int j=0;j<4;j++)
				account[i][j]=new Account();
		}
		
		for(int i=0;i<10;i++)
		{
			cust[i]=new Customer();
			address[i]=new Address();
		}
		
		address[0]=new Address("agv","MIPL","Chennai","TN",603002);
		account[0][0]= new Account((int)(Math.random()*100000),AccountType.SAVINGS,LocalDate.of(2010, Month.JULY, 07),1000);
		
		cust[0] = new Customer(custno++,"Annapoorna",address[0],account[0],"856413257","aghjdn@gmail.com");
		
		
		address[1]=new Address("agv","MIPL","Chennai","TN",603002);
		cust[1] = new Customer(custno++,"Niharika",address[1],account[1],"8214551254","aghshhdn@gmail.com");
		account[1][0]=new Account((int)(Math.random()*100000),AccountType.SAVINGS,LocalDate.of(2012, Month.JULY, 23),1000);
		//cust[1].getAccount()[0]=account;
		
		address[2]=new Address("agv","MIPL","Chennai","TN",603002);
		
		cust[2]= new Customer(custno++,"Madhu",address[2],new Account[5],"821522165","aghdn@gmail.com");
		
		address[3]=new Address("agv","MIPL","Chennai","TN",603002);
		account[3][0]= new Account((int)(Math.random()*100000),AccountType.SAVINGS,LocalDate.of(2012, 04, 22),1000);
		
		
		cust[3]= new Customer(custno++,"Moulya",address[3],account[3],"821522165","a@gmail.com");
		
		address[4]=new Address("agv","MIPL","Chennai","TN",603002);
		account[4][0]= new Account((int)(Math.random()*100000),AccountType.SAVINGS,LocalDate.of(2012, 01, 23),1000);
		
		cust[4]= new Customer(custno++,"Madhu",address[4],account[4],"821522165","aghdn@gmail.com");
		
		
		String bool=null;
		int custid=0;
		int index=0;
		int a=0;
		int cnt=0;
		
		//Finding empty customer object
		for(int i=0;i<10;i++)
		{
			if(cust[i].getCustomerID()==0)
			{
				 break;
			}
			else cnt++;
			
		}
		System.out.println("Enter the customer ID");
		custid= scan.nextInt();
		
	
		
		//Finding customer object corresponding to the custid
		for(index=0;index<cnt;index++)
		{
			//System.out.println("sjdh");
			if(cust[index].getCustomerID()==custid)
			{
				a=index;
				break;
			}
			
		}
		System.out.println(index);
		if(index<=4)
		 {
		System.out.println("CustID: "+cust[a].getCustomerID()+"\nCustomer Name: "+cust[a].getName()+"\nCustomer Address: "+address[a].getStreet() +", "+address[a].getAdd()+", "+address[a].getCity()+", "+address[a].getState()+", "+address[a].getPin()+"\nCustomer Accounts:");
			for(int i=0;i<4;i++)
			{
				if(account[a][i].getAccountNo()==0) break;
				
			System.out.println("Account No.: "+account[a][i].getAccountNo()+"\tAccount Type: "+account[a][i].getAccountType()+"\tAccount Opening Date: "+account[a][i].getOpeningDate()+"\tAccount Opening Balance: "+account[a][i].getOpeningBal());
			//System.out.println(cust[i].getAccount()[i]);	
			
			}
			System.out.println("Customer Mobile No.: "+cust[a].getMobile()+"\nCustomer Email: "+cust[a].getEmail());
			
			//Menu for account creation, do transaction or transaction summary
			do {
			System.out.println("1. Create account \t2. Do Transaction \t3. Transaction Summary");
			int b=scan.nextInt();
				switch (b)
				{
				case 1:
					int j;
					for(j=0;j<4;j++)
					{
						if(account[a][j].getAccountNo()==0)
							break;
					}
					if(j==4)
					{
						System.out.println("You can't create anymore accounts");
					}
					else
					{
						System.out.println("Enter the type of account you want to be created:\n1. Savings\t2.RD\t3.FD\t4.Current");
						int c= scan.nextInt();
						AccountType accountType=selectAccountType(c);
						int opbal;
						System.out.println("What is the opening Balance?");
						opbal=scan.nextInt();
							account[a][j].setAccountNo((int)(Math.random()*100000));
							account[a][j].setAccountType(accountType); 
							account[a][j].setOpeningDate(LocalDate.now());
							account[a][j].setOpeningBal(opbal);
							//account[a][j].setCurrentBal(opbal);
							
						
						
						System.out.println("Your account created Successfully!");
						System.out.println("CustID: "+cust[a].getCustomerID()+"\nCustomer Name: "+cust[a].getName()+"\nCustomer Address: "+address[a].getStreet() +", "+address[a].getAdd()+", "+address[a].getCity()+", "+address[a].getState()+", "+address[a].getPin()+"\nCustomer Accounts:");
						for(int i=0;i<4;i++)
						{
							if(account[a][i].getAccountNo()==0) break;
							
						System.out.println("Account No.: "+account[a][i].getAccountNo()+"\tAccount Type: "+account[a][i].getAccountType()+"\tAccount Opening Date: "+account[a][i].getOpeningDate()+"\tAccount Opening Balance: "+account[a][i].getOpeningBal());
						
						}
						System.out.println("Customer Mobile No.: "+cust[a].getMobile()+"\nCustomer Email: "+cust[a].getEmail());
					}
						
						System.out.println();
						System.out.println("Do you want to continue?[y|n]");
						bool=scan.next();
					
					break;
				case 2:
					
					int k;
					if(account[a][0].getAccountNo()!=0)
					{
						
						while(true)
						{
							
							System.out.println("Enter the account from which you want to make transactions:");
							long accno=scan.nextLong();
							for(k=0;k<4;k++)
							{
								//System.out.println(k);
								if(accno==account[a][k].getAccountNo())
									break;
							
							}
							//System.out.println("shh");
							if(k==4)
							{
								System.out.println("The account no. entered is invalid please try again");
								
							}
							else break;
							}
						Transactions transaction=new Transactions();
											
						System.out.println("Do you want to debit or credit: 1. Debit\t 2.Credit");
						int tran= scan.nextInt();
						if(tran==1)
						{
							
							System.out.println("Enter the amount to be debited:");
							int deb=scan.nextInt();
							transaction.setTransactionType('D');
							transaction.setAccount(account[a][k]);
							transaction.setTransactionID((int)(Math.random()*10000));
							transaction.setTransactionDate(LocalDate.now());
							transaction.setAmount(deb);
							transactions[index1]=transaction;
							index1++;
							//int currBal=(account[a][k].getCurrentBal());
							if(deb >= account[a][k].getOpeningBal())
							{
								System.out.println("Transaction Successful");
								//account[a][k].setCurrentBal(currBal-deb);
								//System.out.println("Current Balance is:"+account[a][k].getCurrentBal());
								
							}
							else
							{
								System.out.println("Amount requested is greater than the current balance");
							}
								
						}
						else
							
						{
							System.out.println("Enter the amount to be credited:");
							int cred=scan.nextInt();
							int deb=scan.nextInt();
							transaction.setTransactionType('C');
							transaction.setAccount(account[a][k]);
							transaction.setTransactionID((int)(Math.random()*10000));
							transaction.setTransactionDate(LocalDate.now());
							transaction.setAmount(cred);
							transactions[index1]=transaction;
							index1++;
							//trans[m]=new Transactions((int)(Math.random()*100000),LocalDate.now(),'C',cred, account[a][k].getAccountNo());
							//trans.
							//int currBal=(account[a][k].getCurrentBal());
							//account[a][k].setCurrentBal(currBal+cred);
								System.out.println("Transaction Successful");
								
								//System.out.println("Current Balance is:"+account[a][k].getCurrentBal());
								
						}
				}
				else
				{
					System.out.println("You dont have any accounts");
				}
					
					System.out.println();
					System.out.println("Do you want to continue?[y|n]");
					bool=scan.next();
					break;
					
				case 3:
					System.out.println("Transaction Summary\n----------------\n");
					for(Transactions transaction:transactions)
					{
						if(transaction!=null)
						System.out.println(transaction.getTransactionID()+" "+transaction.getTransactionType()+" "+transaction.getAccount().getAccountNo());
					}
					
					System.out.println();
					System.out.println("Do you want to continue?[y|n]");
					bool=scan.next();
					
					
				}
				
		
		
			}while(bool.equals("y")|| bool.equals("Y"));
	}
		else { System.out.println("The customer does not exist. Do you want to create a new Customer?[y|n]");
				String b=scan.next();
				if(b.equals("y")||b.equals("Y"))
				{
					System.out.println("Enter the customer Name");
					String name;
					while(true)
					{
					
					name=scan.next();
					
					boolean c=Validate.custName(name);
					if(c==true) break;
					else System.out.println("Enter name containing alphabets only");
					}
					cust[index].setName(name);
				}
		}
	}
	
		
		
	
}