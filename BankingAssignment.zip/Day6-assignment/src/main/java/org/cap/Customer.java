package org.cap;

import java.util.ArrayList;
import java.util.List;

public class Customer {
	
	private int customerID;
	
	private String name;
	private Address address;
	private List<Account> account=new ArrayList<>();
	private String mobile;
	private String email;
	
	public Customer(int custID, String name, Address address, List<Account> account, String mobile, String email) {
		super();
		this.customerID = custID;
		this.name = name;
		this.address = address;
		this.account = account;
		this.mobile = mobile;
		this.email = email;
	}
	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public List<Account> getAccount() {
		return account;
	}

	public void setAccount(List<Account> account) {
		this.account = account;
	}

	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public int getCustomerID() {
		return this.customerID;
	}
	public void setCustomerID(int custID) {
		this.customerID = custID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	

}