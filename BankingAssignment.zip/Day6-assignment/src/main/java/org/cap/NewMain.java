package org.cap;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class NewMain {

	public static AccountType selectAccountType(int c)
	{
		//AccountType accountType;
		if(c==1)
		{
			return AccountType.SAVINGS;
		}
		else if(c==2)
		{
			return AccountType.RD;
		}
		else if(c==3)
		{
			return AccountType.FD;
		}
		else if(c==4)
		{
			return AccountType.CURRENT;
		}
		else {
			 System.out.println("Type Invalid!");
		}
		return null;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int custno=100000;
		Scanner scan= new Scanner(System.in);
		Validate validate=new Validate();
		List<Customer> cust=new ArrayList<>();
		List<Address> address=new ArrayList<>();
		List<Account> account=new ArrayList<>();
		List<List<Account>> account1=new ArrayList<>();
		List<Transactions> transactions= new ArrayList<>();
		int index=0;
		int index1=0;
		address.add(new Address("agv","MIPL","Chennai","TN",603002));
		account.add(new Account((int)(Math.random()*100000),AccountType.SAVINGS,LocalDate.of(2010, Month.JULY, 07),1000));
		account.add(new Account((int)(Math.random()*100000),AccountType.SAVINGS,LocalDate.of(2010, Month.JULY, 07),1000));
		account.add(new Account((int)(Math.random()*100000),AccountType.SAVINGS,LocalDate.of(2010, Month.JULY, 07),1000));
		account1.add(account);
		//System.out.println(account[0]);
		cust.add(new Customer(custno++,"Annapoorna",address.get(0),account1.get(0),"856413257","aghjdn@gmail.com"));
		index++;
		address.add(new Address("agv","MIPL","Chennai","TN",603002));
		
		account.clear();
		account.add(new Account((int)(Math.random()*100000),AccountType.SAVINGS,LocalDate.of(2010, Month.JULY, 07),1000));
		account.add(new Account((int)(Math.random()*100000),AccountType.SAVINGS,LocalDate.of(2010, Month.JULY, 07),1000));
		account.add(new Account((int)(Math.random()*100000),AccountType.SAVINGS,LocalDate.of(2010, Month.JULY, 07),1000));
		account1.add(account);
		cust.add(new Customer(custno++,"Annapoorna",address.get(1),account1.get(1),"856413257","aghjdn@gmail.com"));
		//System.out.println("CustID: "+cust.get(index).getCustomerID()+"\nCustomer Name: "+cust.get(index).getName()+"\nCustomer Address: "+address.get(index).getStreet() +", "+address.get(index).getAdd()+", "+address.get(index).getCity()+", "+address.get(index).getState()+", "+address.get(index).getPin()+"\nCustomer Accounts:");

		String bool=null;
		int custid=0;
		int index2=0;
		int a=0;
		int cnt=0;
		
	
		System.out.println("Enter the customer ID");
		custid= scan.nextInt();
		for(index=0;index<cust.size();index++)
		{
			//System.out.println("sjdh");
			if(cust.get(index).getCustomerID()==custid)
			{
				a=index;
				break;
			}
			
		}
		System.out.println(index);
		if(index<=4)
		 {
		System.out.println("CustID: "+cust.get(a).getCustomerID()+"\nCustomer Name: "+cust.get(a).getName()+"\nCustomer Address: "+address.get(a).getStreet() +", "+address.get(a).getAdd()+", "+address.get(a).getCity()+", "+address.get(a).getState()+", "+address.get(a).getPin()+"\nCustomer Accounts:");
			for(int i=0;i<account1.get(0).size();i++)
			{				

				
			System.out.println("Account No.: "+account1.get(a).get(i).getAccountNo()+"\tAccount Type: "+account1.get(a).get(i).getAccountType()+"\tAccount Opening Date: "+account1.get(a).get(i).getOpeningDate()+"\tAccount Opening Balance: "+account1.get(a).get(i).getOpeningBal());
			//System.out.println(cust[i].getAccount()[i]);	
			
			}
			
			System.out.println("Customer Mobile No.: "+cust.get(a).getMobile()+"\nCustomer Email: "+cust.get(a).getEmail());
			do {
				System.out.println("1. Create account \t2. Do Transaction \t3. Transaction Summary");
				int b=scan.nextInt();
					switch (b)
					{
					case 1:
						int j=account1.get(a).size();
						//System.out.println(j);
						
						if(j==4)
						{
							System.out.println("You can't create anymore accounts");
						}
						else
						{
							System.out.println("Enter the type of account you want to be created:\n1. Savings\t2.RD\t3.FD\t4.Current");
							int c= scan.nextInt();
							AccountType accountType=selectAccountType(c);
							int opbal;
							System.out.println("What is the opening Balance?");
							opbal=scan.nextInt();
							account.add(new Account());
							account1.get(a).get(j).setAccountNo((int)(Math.random()*100000));
							account1.get(a).get(j).setAccountType(accountType); 
							account1.get(a).get(j).setOpeningDate(LocalDate.now());
							account1.get(a).get(j).setOpeningBal(opbal);
								//account[a][j].setCurrentBal(opbal);
									
							System.out.println("Your account created Successfully!");
							System.out.println();
							System.out.println("CustID: "+cust.get(a).getCustomerID()+"\nCustomer Name: "+cust.get(a).getName()+"\nCustomer Address: "+address.get(a).getStreet() +", "+address.get(a).getAdd()+", "+address.get(a).getCity()+", "+address.get(a).getState()+", "+address.get(a).getPin()+"\nCustomer Accounts:");
							for(int i=0;i<=j;i++)
							{
								
								
							System.out.println("Account No.: "+account1.get(a).get(i).getAccountNo()+"\tAccount Type: "+account1.get(a).get(i).getAccountType()+"\tAccount Opening Date: "+account1.get(a).get(i).getOpeningDate()+"\tAccount Opening Balance: "+account1.get(a).get(i).getOpeningBal());
							
							}
							System.out.println("Customer Mobile No.: "+cust.get(a).getMobile()+"\nCustomer Email: "+cust.get(a).getEmail());
						}
							
							System.out.println();
							System.out.println("Do you want to continue?[y|n]");
							bool=scan.next();
						
						break;
					
			case 2:
				
				int k;
				if(account1.get(a).get(0).getAccountNo()!=0)
				{
					
					while(true)
					{
						
						System.out.println("Enter the account from which you want to make transactions:");
						long accno=scan.nextLong();
						for(k=0;k<4;k++)
						{
							//System.out.println(k);
							if(accno==account1.get(a).get(k).getAccountNo())
								break;
						
						}
						//System.out.println("shh");
						if(k==4)
						{
							System.out.println("The account no. entered is invalid please try again");
							
						}
						else break;
						}
					Transactions transaction=new Transactions();
										
					System.out.println("Do you want to debit or credit: 1. Debit\t 2.Credit");
					int tran= scan.nextInt();
					if(tran==1)
					{
						
						System.out.println("Enter the amount to be debited:");
						int deb=scan.nextInt();
						transaction.setTransactionType('D');
						transaction.setAccount(account1.get(a).get(k));
						transaction.setTransactionID((int)(Math.random()*10000));
						transaction.setTransactionDate(LocalDate.now());
						transaction.setAmount(deb);
						transactions[index1]=transaction;
						index1++;
						//int currBal=(account[a][k].getCurrentBal());
						if(deb >= account[a][k].getOpeningBal())
						{
							System.out.println("Transaction Successful");
							//account[a][k].setCurrentBal(currBal-deb);
							//System.out.println("Current Balance is:"+account[a][k].getCurrentBal());
							
						}
						else
						{
							System.out.println("Amount requested is greater than the current balance");
						}
							
					}
					else
						
					{
						System.out.println("Enter the amount to be credited:");
						int cred=scan.nextInt();
						int deb=scan.nextInt();
						transaction.setTransactionType('C');
						transaction.setAccount(account[a][k]);
						transaction.setTransactionID((int)(Math.random()*10000));
						transaction.setTransactionDate(LocalDate.now());
						transaction.setAmount(cred);
						transactions[index1]=transaction;
						index1++;
						trans[m]=new Transactions((int)(Math.random()*100000),LocalDate.now(),'C',cred, account[a][k].getAccountNo());
						//trans.
						int currBal=(account[a][k].getCurrentBal());
						account[a][k].setCurrentBal(currBal+cred);
							System.out.println("Transaction Successful");
							
					
					}
			}
				
			else
			{
				System.out.println("You dont have any accounts");
			}
				
				System.out.println();
				System.out.println("Do you want to continue?[y|n]");
				bool=scan.next();
					break;
				
			case 3:
				System.out.println("Transaction Summary\n----------------\n");
				for(Transactions transaction:transactions)
				{
					if(transaction!=null)
					System.out.println(transaction.getTransactionID()+" "+transaction.getTransactionType()+" "+transaction.getAccount().getAccountNo());
				}
				
				System.out.println();
				System.out.println("Do you want to continue?[y|n]");
				bool=scan.next();
				
				
			
			

					}
		 
			}while(bool.equals("y")|| bool.equals("Y"));
		 
		 }
	
		else { System.out.println("The customer does not exist. Do you want to create a new Customer?[y|n]");
		String b=scan.next();
		if(b.equals("y")||b.equals("Y"))
		{
			System.out.println("Enter the customer Name");
			String name;
			while(true)
			{
			
			name=scan.next();
			
			boolean c=Validate.custName(name);
			if(c==true) break;
			else System.out.println("Enter name containing alphabets only");
			}
			cust.get(index).setName(name);
		}
}
}




}
