package org.cap;

import java.time.LocalDate;

public class Transactions {
	
	private int transactionID;
	private LocalDate transactionDate;
	private char transactionType;
	private double amount;
	private Account account;
	
	public Transactions()
	{
		
	}
	
	public Transactions(int transactionID, LocalDate transactionDate, char transactionType, double amount,
			Account account) {
		super();
		this.transactionID = transactionID;
		this.transactionDate = transactionDate;
		this.transactionType = transactionType;
		this.amount = amount;
		this.account = account;
	}
	
	
	public int getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}
	public LocalDate getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}
	public char getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(char transactionType) {
		this.transactionType = transactionType;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	

}
