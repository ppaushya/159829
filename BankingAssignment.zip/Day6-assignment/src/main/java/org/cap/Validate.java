package org.cap;

public class Validate {

		public static boolean custID(String str)
		{
			boolean b=str.matches("\\d[0-9]{6,10}");
			return b;
		}
		
		public static boolean custName(String name) {
			// TODO Auto-generated method stub
			boolean b=name.matches("[A-Za-z]+");
			return b;
		}
}
