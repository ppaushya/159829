package org.cap.demo;

import java.util.Scanner;

public class UserInteraction {

	Scanner scan=new Scanner(System.in);
	public Product getProductDetails(Product product) {
		
		System.out.println("Enter the product ID");
		product.setProductID(scan.nextInt());	
		System.out.println("Enter the product name");
		product.setProductName(scan.next());
		System.out.println("Quantity");
		product.setQuantity(scan.nextInt());
		System.out.println("Amount");
		product.setAmount(scan.nextDouble());
		return product;
		// TODO Auto-generated method stub
		
	}

}
