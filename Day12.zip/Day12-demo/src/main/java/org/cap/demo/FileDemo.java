package org.cap.demo;

import java.io.File;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		File file=new File("D:\\Users\\bannapoo\\Desktop\\MyDemo1.txt");
		if(file.exists())
		{
		if(file.isFile())
		{
			System.out.println("Readable:"+file.canRead());
			System.out.println("Writeable:"+file.canWrite());
			System.out.println("Executeable:"+file.canExecute());
			System.out.println("AbsolutePath:"+file.getAbsolutePath());
			
		}
		
		else if(file.isDirectory())
		{
			String[] names=file.list();
			for(String name:names)
			{
				System.out.println(name);
			}
		}
		}
		else
		{
			System.out.println("Sorry!No file exists");
			try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println("FreeSpace:"+file.getFreeSpace());
		System.out.println("TotalSpace:"+file.getTotalSpace());
		System.out.println("UsableSpace:"+file.getUsableSpace());

	}

}
