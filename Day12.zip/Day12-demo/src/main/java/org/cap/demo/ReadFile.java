package org.cap.demo;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

//import jdk.jfr.events.FileWriteEvent;

public class ReadFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int empID=100;
		String name="Annapoorna";
		double salary=70000;
		char gender='m';
		
		File file=new File("D:\\Users\\bannapoo\\Desktop\\MyDemo1.txt");
		
		if(file.exists())
		{
			try(FileOutputStream out=new FileOutputStream(file);
					DataOutputStream outputStream=new DataOutputStream(out))
			{
				for(int i=0;i<5;i++)
				{
				outputStream.writeInt(empID);
				outputStream.writeDouble(salary);
				outputStream.writeChar(gender);
				outputStream.writeInt(name.length());
				outputStream.write(name.getBytes());
				}
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
		try(FileInputStream in=new FileInputStream(file);
			DataInputStream inputStream=new DataInputStream(in)){
			int cnt=0;
			for(int i=0;i<5;i++)
			{
			int a=inputStream.readInt();
			double sal=inputStream.readDouble();
			char gend=inputStream.readChar();
			int length=inputStream.readInt();
			
			char names[]=new char[length];
			for(int j=0;j<length;j++)
			{
			names[cnt]=((char)inputStream.read());
			cnt++;
			}
			cnt=0;
			
			String name1=new String(names);
			
			System.out.println(a+" "+sal+" "+gend+" "+" "+name1);
			
			}
					
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	}
}
