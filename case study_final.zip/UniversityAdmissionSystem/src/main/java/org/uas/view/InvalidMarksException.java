package org.uas.view;

public class InvalidMarksException extends Exception {
	
	
	public InvalidMarksException(String string)
	{
		super(string);
	}

}
