package org.uas.service;

import java.util.List;

import org.uas.model.Application;
import org.uas.model.Participant;
import org.uas.model.ProgramsOffered;
import org.uas.model.ProgramsSchedule;
import org.uas.view.InvalidMarksException;

public interface I_UAS_Service {

	public List<ProgramsOffered> getAllProgramsOffered();
	public List<Application> getAllApplicants(int programId);
	public Application apply(Application application);
	public String getStatus(int appId);
	public boolean isVAlidLogin(int username, String pwd);
	public boolean updateApplicationStatus(Application application);
	public boolean createParticipant(Participant participant);
	public boolean isVAlidMarks(int marksObtained) throws InvalidMarksException;
	public boolean isValidProgram(int programId);
	public String getEligibilityCriteria(int programId);
	public List<ProgramsSchedule> getProgramSchedules();
	
}
