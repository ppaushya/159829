package org.cap.test;

import static org.junit.Assert.*;

import org.cap.demo.Calculation;
import org.junit.Test;

public class MyFirstTest {

	@Test
	public void test_Add() {
		
		Calculation calculate=new Calculation();
		assertEquals(155,calculate.addNumber(5, 10));
	}

}
