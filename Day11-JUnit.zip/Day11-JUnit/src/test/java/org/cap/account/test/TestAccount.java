package org.cap.account.test;

import static org.junit.Assert.*;

import java.beans.BeanProperty;

import org.cap.account.service.InvalidAmountException;
import org.cap.account.dao.IAccountDao;
import org.cap.account.model.Account;
import org.cap.account.model.Address;
import org.cap.account.model.Customer;
import org.cap.account.service.AccountServiceImpl;
import org.cap.account.service.IAccountService;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class TestAccount {
	
	@Mock
	private IAccountDao accountDao;
	
	
	private IAccountService accountService;
	
	@Before
	public void setUp()
	{
		
		MockitoAnnotations.initMocks(this);
		//System.out.println("Object created");
		accountService=new AccountServiceImpl(accountDao);
	}
	
	
	
	@Test(expected=IllegalArgumentException.class)
	public void when_createAccount_with_null_customer()
				throws InvalidAmountException {
		Customer customer=null;
		accountService.createAccount(customer, 3000);

	}
	
	
	
	@Test(expected=InvalidAmountException.class)
	public void when_createAccount_with_invalid_amount()

				throws InvalidAmountException {
		Customer customer=new Customer();
		Address address=new Address("Chennai");
		customer.setAddress(address);
		customer.setCustomerID(101);
		customer.setCustomerName("Annapoorna");
		accountService.createAccount(customer, 10000);
	}
	
	@Test
	public void when_create_account() throws InvalidAmountException
	{
		Customer customer=new Customer();
		Address address=new Address("Chennai");
		customer.setAddress(address);
		customer.setCustomerID(101);
		customer.setCustomerName("Annapoorna");
		//accountService.createAccount(customer, 1000);
		
		//dummy Declaration
		Mockito.when(accountDao.addAccount(customer)).thenReturn(true);
		
		//Actual Logic Triggered
		Account account=accountService.createAccount(customer, 3000);
		
		//verification
		Mockito.verify(accountDao).addAccount(customer);
		assertNotNull(account);
		assertEquals(3000, account.getBalance(),0.0);
		
		
		
	}

}











