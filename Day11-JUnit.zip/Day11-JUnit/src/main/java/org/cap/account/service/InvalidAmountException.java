package org.cap.account.service;

public class InvalidAmountException extends Exception {
	
	public InvalidAmountException(String string)
	{
		System.out.println(string);
	}

}
