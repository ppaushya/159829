package org.cap.account.service;

import org.cap.account.model.Account;
import org.cap.account.model.Customer;

public interface IAccountService {
	
	
	public Account createAccount(Customer customer, double amount) throws InvalidAmountException;

	void withdraw(Customer customer, double amount);
	

}
