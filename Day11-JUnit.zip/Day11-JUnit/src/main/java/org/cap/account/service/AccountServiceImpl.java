package org.cap.account.service;

import org.cap.account.dao.AccountDaoImpl;
import org.cap.account.dao.IAccountDao;
import org.cap.account.model.Account;
import org.cap.account.model.Customer;

public class AccountServiceImpl implements IAccountService{
	
	private IAccountDao accountDao=new AccountDaoImpl();
	
	public AccountServiceImpl(IAccountDao accountDao)
	{
		this.accountDao=accountDao;
	}
	@Override
	public Account createAccount(Customer customer, double amount) throws InvalidAmountException{
		if(customer==null)
			throw new IllegalArgumentException("Invalid Customer!");
		if(amount<1000)
			throw new InvalidAmountException("Invalid amount");
		
		Account account=new Account();
		account.setAccountNo((long)(Math.random()*1000));
		account.setAccountType("savings");
		account.setBalance(amount);
		customer.setAccount(account);
		
		if(accountDao.addAccount(customer))
			return account;
		else
				return null;
		
	}
	@Override
	public void withdraw(Customer customer, double amount) {
		// TODO Auto-generated method stub
		
	}
	
	

	
	


}
