package org.cap.account.model;

public class Address {
	private String addressLine1;

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public Address(String addressLine1) {
		super();
		this.addressLine1 = addressLine1;
	}
	


}
