package org.cap.account.dao;

import org.cap.account.model.Account;
import org.cap.account.model.Customer;

public class AccountDaoImpl implements IAccountDao {

	@Override
	public boolean addAccount(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}
	

}
