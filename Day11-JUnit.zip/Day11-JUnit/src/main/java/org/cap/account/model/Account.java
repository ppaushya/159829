package org.cap.account.model;

public class Account {
	private long accountNo;
	private String accountType;
	private double balance;
	
	public Account()
	{
		
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Account(long accountNo, String accountType, double balance) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.balance = balance;
	}
	
	 

}
