package org.cap.demo;

public class Calculation {

	
	public int addNumber(int a,int b)

		{
		
		int sum=a+b;
		return sum;
		}
}
