package com.capg.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Repository;

import com.capg.model.Customer;


@Repository("customerDao")

public class CustomerDaoImpl implements ICustomerDao{
	
	
	private static AtomicInteger customerId=new AtomicInteger(1000);
	private static  List<Customer> customers=dummyDB();

	
	
	private static  List<Customer> dummyDB() {
		
		
		List<Customer> customers=new ArrayList<>();
		
			
			customers.add(new Customer(customerId.incrementAndGet(), "Tom", "Jerry", LocalDate.of(2000, 02, 27), "tom@gmail.com", "9876543210", "tom123"));
			customers.add(new Customer(customerId.incrementAndGet(), "Tom", "Harrison", LocalDate.of(2000, 02, 27), "tommy@gmail.com", "9876543210", "tom123"));
		
			return customers;
	}




	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customers ;
	}

	
	@Override
	public Customer findCustomer(Integer custId) {
		// TODO Auto-generated method stub
		
		Iterator<Customer> iterator=customers.iterator();
		while(iterator.hasNext())
		{
			Customer customer=iterator.next();
			if(customer.getCustomerId()==custId)
			{
				return customer;
			}
		}
		return null;
	}

	@Override
	public List<Customer> deleteCustomer(Integer custId) {
		// TODO Auto-generated method stub
		
		ListIterator<Customer> iterator=customers.listIterator();
		while(iterator.hasNext())
		{
			
			Customer customer=iterator.next();
			if(customer.getCustomerId()==custId)
			{
				iterator.remove();
			}
			
			
		}
		
		return customers;
	}

	@Override
	public List<Customer> createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		customer.setCustomerId(customerId.incrementAndGet());
		customers.add(customer);
		return customers;
	}

	@Override
	public List<Customer> updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		int index=0;
		for(Customer customer1:customers)
		{
			System.out.println(customer);
			if(customer1.getCustomerId()==customer.getCustomerId())
			{
				customers.set(index, customer);
			}
			index++;
		}
		return customers;
	}

	@Override
	public List<Customer> updatePartialCustomer(String email, int custId) {
		// TODO Auto-generated method stub
		for(Customer customer1:customers)
		{
			if(customer1.getCustomerId()==custId)
			{
				customer1.setEmailId(email);
			}
		}
		return customers;
	}
	
	
	

}
