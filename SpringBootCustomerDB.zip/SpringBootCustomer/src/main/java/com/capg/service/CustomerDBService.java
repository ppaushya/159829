package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.dao.CustomerDBImpl;
import com.capg.model.Customer;

@Service("customerDBService")
public class CustomerDBService implements ICustomerService {

	@Autowired
	CustomerDBImpl customerDB;
	
	
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customerDB.findAll();
	}

	@Override
	public Customer findCustomer(Integer custId) {
		// TODO Auto-generated method stub
		
		Customer customer=customerDB.findById(custId).get();
		return customer;
	}

	@Override
	public List<Customer> deleteCustomer(Integer custId) {
		
		customerDB.deleteById(custId);
		return customerDB.findAll();
	}

	@Override
	public List<Customer> createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		
		customerDB.save(customer);
		return customerDB.findAll();
	}

	@Override
	public List<Customer> updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		
		customerDB.saveAndFlush(customer);
		return customerDB.findAll();
	}

	@Override
	public List<Customer> updatePartialCustomer(String email, int custId) {
		// TODO Auto-generated method stub
		return null;
	}

}
