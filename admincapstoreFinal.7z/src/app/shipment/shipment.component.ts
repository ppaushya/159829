import { Component, OnInit } from '@angular/core';
import { Shipment } from '../models/Shipment';
import { ShipmentService } from './shipment.service';
import { AppService } from '../app.service';
import { trigger, style, transition, animate, keyframes, query, stagger } from '@angular/animations';

@Component({
  selector: 'app-shipment',
  templateUrl: './shipment.component.html',
  styleUrls: ['./shipment.component.css'],
  animations: [
    trigger('ml', [
      transition('* => *',
        [
          query(':enter', style({ opacity: 0 }), { optional: true }),

          query(':enter', stagger('300ms', [

            animate('.6s ease-in', keyframes([
              style({ opacity: 0, transform: 'translateY(-75%)', offset: 0 }),
              style({ opacity: 0.5, transform: 'translateY(35px)', offset: .3 }),
              style({ opacity: 1, transform: 'translateY(0)', offset: 1 })
            ]))]), { optional: true }),

          query(':leave', stagger('300ms', [

            animate('.6s ease-in', keyframes([
              style({ opacity: 1, transform: 'translateY(0)', offset: 0 }),
              style({ opacity: 0.5, transform: 'translateY(35px)', offset: .3 }),
              style({ opacity: 0, transform: 'translateY(-75%)', offset: 1 })
            ]))]), { optional: true }),

        ])

    ])

  ]
})
export class ShipmentComponent implements OnInit {
  shipments: Shipment[];
  length:number;

  constructor(private shipmentService: AppService) { }

  ngOnInit() {
    this.getShipments();
  }

  getShipments(): void {
    this.shipmentService.getShipments().subscribe(
      shipments => {
      this.shipments = shipments;
      this.length = this.shipments.length;
      console.log('Shipments here!!');
      console.log(this.shipments);
      });
  }

  updateShipment(shipment:Shipment,status:string): void {
    this.shipmentService.updateShipment(shipment.shipmentId,status).subscribe(
      success => {
        if(success){
          shipment.deliveryStatus = status;
          shipment.changedDeliveryStatus = undefined;
        }
        console.log(success);
      });
  }


}
