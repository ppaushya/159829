import { Component, OnInit } from '@angular/core';
import { Product } from '../models/Product';
import { AppService } from '../app.service';
import { trigger, style, transition, animate, keyframes, query, stagger } from '@angular/animations';


@Component({
  selector: 'app-promo-email',
  templateUrl: './promo-email.component.html',
  styleUrls: ['./promo-email.component.css'],
  animations: [
    trigger('ml', [
      transition('* => *',
        [
          query(':enter', style({ opacity: 0 }), { optional: true }),

          query(':enter', stagger('300ms', [

            animate('.6s ease-in', keyframes([
              style({ opacity: 0, transform: 'translateY(-75%)', offset: 0 }),
              style({ opacity: 0.5, transform: 'translateY(35px)', offset: .3 }),
              style({ opacity: 1, transform: 'translateY(0)', offset: 1 })
            ]))]), { optional: true }),

          query(':leave', stagger('300ms', [

            animate('.6s ease-in', keyframes([
              style({ opacity: 1, transform: 'translateY(0)', offset: 0 }),
              style({ opacity: 0.5, transform: 'translateY(35px)', offset: .3 }),
              style({ opacity: 0, transform: 'translateY(-75%)', offset: 1 })
            ]))]), { optional: true }),

        ])

    ])

  ]
})
export class PromoEmailComponent implements OnInit {

  products: Product[] =[];
  length:number;
  emailSentStatus:boolean = false;
  showEmailSentStatus:boolean = false;

  constructor(private appService: AppService) { }

  ngOnInit() {
    this.getNewProductWithoutEmailsSent();
  }

  getNewProductWithoutEmailsSent(){
    this.appService.getNewProductWithoutEmailsSent().subscribe(
      products => {
        this.products = products;
        this.length=this.products.length;
      }
    );
  }

  sendNewProductEmailsToAllCustomer():void{
    this.appService.sendNewProductEmailsToAllCustomer().subscribe(
      success => {
        this.emailSentStatus = success;
        this.showEmailSentStatus = true;
        this.getNewProductWithoutEmailsSent();
      }
    );
  }
}
