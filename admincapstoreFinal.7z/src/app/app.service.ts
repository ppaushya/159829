import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ISalesAnalysis } from './business-analysis/ISalesAnalysis';
import { Promos } from './models/Promos';
import { Customer } from './models/Customer';
import { Coupon } from './models/coupon';
import { Merchant } from './models/merchant';
import { Inventory } from './models/Inventory';
import { Shipment } from './models/Shipment';
import { Product } from './models/Product';
import { Feedback } from './models/Feedback';
import { IDispatchAnalysis } from './business-analysis/IDispatchAnalysis';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private _http: HttpClient) { }

  //businessAnalysis - sales analysis
  getSalesAnalysis(fromDate:Date, toDate:Date): Observable<ISalesAnalysis[]> {
    let url = "http://localhost:8086/capstore/api/v1/salesAnalysis/"+fromDate+"/to/"+toDate;
    return this._http.get<ISalesAnalysis[]>(url)
  }

  //businessAnalysis - dispatch analysis
  getDispatchAnalysis(fromDate:Date, toDate:Date): Observable<IDispatchAnalysis[]> {
    let url = "http://localhost:8086/capstore/api/v1/dispatchAnalysis/"+fromDate+"/to/"+toDate;
    return this._http.get<IDispatchAnalysis[]>(url)
  }

  //byCategory
  getProductCategory(): Observable<string[]> {
    let url = "http://localhost:8086/capstore/api/v1/getCategories"
    return this._http.get<string[]>(url)
  };
  getAllPromos(): Observable<Promos[]> {
    return this._http.get<Promos[]>("http://localhost:8086/capstore/api/v1/getAllPromos");
  }
  editByCategory(promoCode: string, category: string): Observable<Boolean> {
    return this._http.get<Boolean>("http://localhost:8086/capstore/api/v1/editAllPromos/" + promoCode + "/" + category);
  }

  //customer
  getCustomers(): Observable<Customer[]> {
    //console.log(('Customers here!!'+this.http.get<Customer[]>(this.custUrl+'/all')));
    let url = "http://localhost:8086/capstore/api/v1/customers";
    return this._http.get<Customer[]>(url);
  }
  deleteCustomer(customerId: number): Observable<Customer[]> {
    let url = "http://localhost:8086/capstore/api/v1/customers";
    return this._http.delete<Customer[]>(url);
  }

  //generateCoupons
  coupon: Coupon=new Coupon();
  generatecoupon(coupons: Coupon): Observable<Coupon> {
    let url = "http://localhost:8086/capstore/api/v1/generateCoupon";
    return this._http.post<Coupon>(url, coupons, {});
  }
  
  setCoupon(coupon: Coupon): void {
    this.coupon = coupon;
  }
 
  getCoupon(){
      return this.coupon;
  }

  //merchant
  getMerchants(): Observable<Merchant[]> {
    //console.log(('Merchants here!!'+this.http.get<Merchant[]>(this.custUrl+'/all')));
    let url = "http://localhost:8086/capstore/api/v1/merchants/all"
    return this._http.get<Merchant[]>(url);
  }
  deleteMerchant(merchantId: number): Observable<Merchant[]> {
    let url = "http://localhost:8086/capstore/api/v1/merchantReject"
    url = url + '/' + merchantId;
    return this._http.get<Merchant[]>(url);
  }
  verifyMerchant(merchantId: number): Observable<Merchant[]> {
    return this._http.get<Merchant[]>('http://localhost:8086/capstore/api/v1/merchantVerification/' + merchantId);
  }
  inviteMerchant(merchantMailID: string): Observable<boolean> {
    return this._http.post<boolean>("http://localhost:8086/capstore/api/v1/inviteMerchant", merchantMailID);
  }

  //product
  getInventories(): Observable<Inventory[]> {
    //console.log(('Inventories here!!'+this.http.get<Inventory[]>(this.custUrl)));
    let url = "http://localhost:8086/capstore/api/v1/viewInventories"
    return this._http.get<Inventory[]>(url);
  }

  deleteInventory(inventoryId: number): Observable<Inventory[]> {
    let url = "http://localhost:8086/capstore/api/v1/viewInventories"
    url = url + '/' + inventoryId;
    return this._http.delete<Inventory[]>(url);
  }
  editInventory(inventory: Inventory): Observable<Inventory[]> {
    return this._http.post<Inventory[]>('http://localhost:8086/capstore/api/v1/inventory', inventory, {});
  }
  getPromo(promoCode: string): Observable<Promos> {
    return this._http.get<Promos>("http://localhost:8086/capstore/api/v1/getPromo/" + promoCode);
  }

  //promo
  addPromo(promo: Promos): Observable<Boolean> {
    let url = "http://localhost:8086/capstore/api/v1/inventories"
    return this._http.post<Boolean>(url + '/promo', promo);
  }

  //shipment
  private shipmentUrl='http://localhost:8086/capstore/api/v1/shipment/all';
  private shipmentUpdateUrl='http://localhost:8086/capstore/api/v1/updateShipmentDeliveryStatus';
  getShipments(): Observable<Shipment[]> {
    return this._http.get<Shipment[]>(this.shipmentUrl);
  }
  updateShipment(shipmentId: number, status: string): Observable<boolean> {
    return this._http.post<boolean>(
      this.shipmentUpdateUrl + '/' + shipmentId + '/' + status
      , null, {});
  }

  //promotional emails
  private NewProductWithoutEmailsSentUrl='http://localhost:8086/capstore/api/v1/sendemail';
  private newProductPromoEmailUrl='http://localhost:8086/capstore/api/v1/sendemail/newproduct';
  private newPromoPromoEmailUrl='http://localhost:8086/capstore/api/v1/sendemail/promo';
  private newCouponPromoEmailUrl='http://localhost:8086/capstore/api/v1/sendemail/coupon';
  getNewProductWithoutEmailsSent(): Observable<Product[]> {
    return this._http.get<Product[]>(this.NewProductWithoutEmailsSentUrl);
  }
  sendNewProductEmailsToAllCustomer(): Observable<boolean> {
    return this._http.post<boolean>(this.newProductPromoEmailUrl,null,{});
  }
  sendNewPromoEmailsToAllCustomer(promo: Promos): Observable<boolean> {
    return this._http.post<boolean>(this.newPromoPromoEmailUrl,promo,{});
  }
  sendNewCouponEmailsToAllCustomer(coupon: Coupon): Observable<boolean> {
    return this._http.post<boolean>(this.newCouponPromoEmailUrl,coupon,{});
  }

  //feedback
  getAllFeedbacks():Observable<Feedback[]>{
    return this._http.get<Feedback[]>("http://localhost:8086/capstore/api/v1/allFeedbacks");
  }
  getNumberOfFeedbacksPerMerchant():Observable<Number[]>{
    return this._http.get<Number[]>("http://localhost:8086/capstore/api/v1/getNumberOfFeedbacksPerMerchant");
  }

  //Product(Upload Image)

  pushFileToStorage(file: File,productId:number): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();
    
    formdata.append('file', file);


    const req = new HttpRequest('POST', 'http://localhost:8086/capstore/api/v1/post/'+productId, formdata, {
      reportProgress: true,
      responseType: 'text'
    });

    return this._http.request(req);
  }
  pushSliderToStorage(file: File,productId:number,id:number): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();
    
    formdata.append('file', file);


    const req = new HttpRequest('POST', 'http://localhost:8086/capstore/api/v1/slider/'+productId+'/'+id, formdata, {
      reportProgress: true,
      responseType: 'text'
    });

    return this._http.request(req);
  }
  getProducts():  Observable<Product[]> {
    return this._http.get<Product[]>('http://localhost:8086/capstore/api/v1/viewProducts');
  }

  getFiles(): Observable<Product[]> {
    return this._http.get<Product[]>('http://localhost:8086/capstore/api/v1/getallfiles');
  }
}
