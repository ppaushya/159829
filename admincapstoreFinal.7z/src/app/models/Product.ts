import { Promos } from "./Promos";
import { Inventory } from "./Inventory";

export class Product{
   
    productId:number;
    productName:string;
    productCategory:string;
    inventory:Inventory;
    productPrice:number;
    promo:Promos;
    productsSold:string;
    productView:number;
    isPromotionMessageSent:boolean;
    productDescription:string;
    quantity:number;
    discount:number;
    brand:string;
   
}