export interface Promos{
    "promoId":number;
    "promoCode":string;
    "discount":number;
    "promoImageUrl":string;
    "endDate":Date;
}