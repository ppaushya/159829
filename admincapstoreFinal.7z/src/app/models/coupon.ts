export class Coupon{
    couponId: number;
    maxDiscount: number;
    couponCode: number;
    discountPercentage:number;
    isCouponAvailable:boolean;
    couponImageUrl:string;
}