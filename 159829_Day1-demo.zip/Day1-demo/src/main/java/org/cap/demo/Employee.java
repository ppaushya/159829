package org.cap.demo;

import java.util.Scanner;

public class Employee {
	 int empID;
	 String empName;
	 int age;
	 boolean isPermanent;
	 String gender;
	 String address;
	 public void getEmployee()
	 {
		 Scanner scanner=new Scanner(System.in);
		 System.out.println("Enter empID: ");
		 empID=scanner.nextInt();
		 System.out.println("Enter empName: ");
		 empName=scanner.next();
		 System.out.println("Enter age: ");
		 age=scanner.nextInt();
		 System.out.println("Enter isPermanent: ");
		 isPermanent=scanner.nextBoolean();
		 System.out.println("Enter gender: ");
		 gender=scanner.next();
		 System.out.println("Enter address: ");
		 address=scanner.next();
		  scanner.close();
		 
	 }
	 public void printEmployee() {
		 System.out.println("\nEmployee Details:\nEmpID: "+empID+"\nempName: "+empName+"\nAge: "+age+"\nisPermanent?: "+isPermanent+"\nGender: "+gender+"\nAddress: "+address);
	 }
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		Employee obj= new Employee();
		
obj.getEmployee();
obj.printEmployee();
	}

}
