package org.cap.demo;

import java.util.Scanner;

public class Student {
	String name;
	int mark1,mark2,mark3;
	public void getStudent()
	{
		Scanner scan= new Scanner(System.in);
		System.out.println("Enter Student NAme");
		name= scan.nextLine();
		System.out.println("Enter Student marks");

		mark1=scan.nextInt();
		mark2=scan.nextInt();
		mark3=scan.nextInt();
			scan.close();	
	}
	public int findScore()
	{
		int score=mark1+mark2+mark3;
		return score;
	}
	public int findAvg()
	{
		int score=findScore();
		return score/3;
	}
	public void printStudent()
	{
		int a= findScore();
		int b=findAvg();
		System.out.println("Student's Name: "+name+"\nMark1: "+mark1+"\nMark2: "+mark2+"\nMark3: "+mark3+"\nScore: "+a+"\nAverage: "+b);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student obj=new Student();
		obj.getStudent();
		obj.printStudent();
	}

}
