package org.cap.demo;

public class TestStatic {
	String name;
	static int count;
	final float pi=3.14f;
	public static void show()
	{
		System.out.println("Count: "+count);
		//System.out.println("Name: "+name);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestStatic obj=new TestStatic();
		obj.name="TOM";
		obj.count=10;
		obj.show();
		System.out.println("Pi: "+obj.pi);
		//obj.pi=5.15;
		//System.out.println(obj.name);
	
	//	System.out.println(obj1.name);
		
	}

}
